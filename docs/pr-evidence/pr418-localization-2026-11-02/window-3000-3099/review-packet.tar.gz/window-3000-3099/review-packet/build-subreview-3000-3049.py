import collections, hashlib, json, re, subprocess
from datetime import datetime, timezone
from pathlib import Path

P=Path('/mnt/disks/scratch/task-scratch/seerrng-pr418-window-3000-3099-primary-20261102')
HEAD='5df4c711f832f1f9a818c4d9cfca46661bff0835'
TREE='116ff2934d7eaf3d02f84f104621860c16babc01'
SUMS_SHA='85659f2a2d070e5d3689dd9fa91399a587ae70280ee45c9d2d4a807082ac90b7'
CELLS_SHA='70f8516d2620f1e517da192831fbf429ae917f1e24a361f833e5f8593422b3e6'
CALLERS_SHA='9bb05efa1e184e851dcb75dde4cdb004f55c471b04c737dcf0034f2b69fe78da'
TRIAGE_SHA='71536ee89ffb8a7113bca5f779a3501816a96339d4afb9105bf8a55753882775'
HEAD_REPORT_SHA='8662f69fb3d4c4e488ee83197c45005787a239e42a447a75b0f143e7e2346079'
PROPOSALS_SHA='f11e4d1dbd2e41132b0ce931203c47069b6ce6e8a18e38747554f8ea9860af68'
PROPOSALS=P/'manual-proposals.jsonl'
LOCALES=['ar','de','es','fr','hi','id','ja','ko','pt_BR','vi','zh_Hans','zh_Hant']
CELLS=P/'source-current-cells-resolved.jsonl'
CALLERS=P/'caller-contexts-resolved.jsonl'
TRIAGE=P/'caller-gap-extraction-triage.json'
HEAD_REPORT=P/'head-reattestation.json'
ROWS_OUT=P/'subreview-3000-3049.jsonl'
SUMMARY_OUT=P/'subreview-3000-3049-summary.json'
ATTEST_OUT=P/'subreview-3000-3049-reattestation.json'
README_OUT=P/'subreview-3000-3049-README.md'
MANIFEST_OUT=P/'SUBREVIEW-MANIFEST-3000-3049.json'
SUMS_OUT=P/'SUBREVIEW-SHA256SUMS-3000-3049'

def sha(data):
    if isinstance(data,str): data=data.encode('utf-8')
    return hashlib.sha256(data).hexdigest()
def canonical_sha(obj):
    return sha(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')))
def readj(path): return json.loads(path.read_text(encoding='utf-8'))
def readjl(path): return [json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
def wjson(path,obj): path.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def wjsonl(path,rows): path.write_text(''.join(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n' for x in rows),encoding='utf-8')

# Independent findings; unspecified cells were reviewed and accepted as-is.
D={}
def add(pos,loc,target,verdict,why,confidence='moderate'):
    D[(pos,loc)]={'target':target,'verdict':verdict,'why':why,'confidence':confidence}
for loc in LOCALES:
    add(3001,loc,None,'hold',
        'No production caller was found for this key at the exact head. It appears only at the English definition; the adjacent quota chooser routes to seasonlimit and has no magazine-specific branch. Confirm or fix the caller before using any translation.', 'high')
for pos, vals, why in [
 (3004,{'vi':'album nhạc','zh_Hans':'音乐专辑','zh_Hant':'音樂專輯'},
  'This is the music-request category; the current Vietnamese means a volume/episode and the Chinese targets mean a photo album.'),
 (3005,{'vi':'{limit, plural, one {album nhạc} other {album nhạc}}','zh_Hans':'{limit, plural, one {音乐专辑} other {音乐专辑}}','zh_Hant':'{limit, plural, one {音樂專輯} other {音樂專輯}}'},
  'This is the music-album quota; the current Vietnamese means a volume/episode and the Chinese targets mean a photo album.')]:
    for loc,target in vals.items(): add(pos,loc,target,'correction',why)
add(3005,'pt_BR','{limit, plural, one {álbum} many {álbuns} other {álbuns}}','refinement','Lowercase the noun in the plural branches following a numeric limit.')
add(3006,'ar','لم يتبقَّ عدد كافٍ من طلبات المواسم','refinement','The current says the maximum was consumed; this keeps the exact “not enough requests remaining” meaning.')
add(3006,'zh_Hans','剩余的剧季请求不足','correction','The current omits the season-request type; this is a series-season quota.')
add(3006,'zh_Hant','剩餘的影集季請求不足','correction','The current omits the season-request type; this is a series-season quota.')
add(3007,'hi','आप अपने अनुरोधों की सीमाओं का सारांश <ProfileLink>प्रोफ़ाइल पृष्ठ</ProfileLink> पर देख सकते हैं।','refinement','Add the missing relation before the profile link and smooth the Hindi sentence.')
add(3007,'vi','Bạn có thể xem bản tóm tắt các giới hạn yêu cầu của bạn trên <ProfileLink>trang hồ sơ</ProfileLink>.','correction','The current omits “on” before the profile link.')
add(3007,'zh_Hans','你可以在自己的<ProfileLink>个人资料页面</ProfileLink>查看请求限额摘要。','refinement','Restore “you can view” and remove the extra space before punctuation.')
add(3007,'zh_Hant','您可以在自己的<ProfileLink>個人資料頁面</ProfileLink>查看請求限額摘要。','refinement','Restore “you can view” and remove the extra space before punctuation.')
add(3008,'id','Anda dapat melihat ringkasan batas permintaan pengguna ini di <ProfileLink>halaman profil pengguna ini</ProfileLink>.','correction','The current “pada mereka” misstates whose profile page this is.')
add(3008,'vi','Bạn có thể xem bản tóm tắt các giới hạn yêu cầu của người dùng này trên <ProfileLink>trang hồ sơ của họ</ProfileLink>.','correction','The current “trên họ” is ungrammatical for “on their profile page.”')
add(3008,'zh_Hans','你可以在此用户的<ProfileLink>个人资料页面</ProfileLink>查看其请求限额摘要。','refinement','Restore “you can view” and remove the extra space before punctuation.')
add(3008,'zh_Hant','您可以在此使用者的<ProfileLink>個人資料頁面</ProfileLink>查看其請求限額摘要。','refinement','Restore “you can view” and remove the extra space before punctuation.')

rr={
'de':('{remaining, plural, =0 {Keine} other {<strong>#</strong>}} {remaining, plural, one {Anfrage für {type} verbleibt} other {Anfragen für {type} verbleiben}}','“Anfrage” is placed awkwardly; this orders the request around its category.'),
'es':('{remaining, plural, =0 {No quedan} other {Quedan <strong>#</strong>}} {remaining, plural, one {solicitud} many {solicitudes} other {solicitudes}} de {type}','The current places the category before solicitud; the normal order is solicitudes de {type}.'),
'fr':('{remaining, plural, =0 {Aucune} other {<strong>#</strong>}} {remaining, plural, =0 {demande de {type} restante} one {demande de {type} restante} many {demandes de {type} restantes} other {demandes de {type} restantes}}','The current can produce “Aucune film demande”; move the category after demande and agree the zero branch.'),
'hi':('{remaining, plural, =0 {कोई} other {<strong>#</strong>}} {type} अनुरोध {remaining, plural, =0 {शेष नहीं है} one {शेष है} other {शेष हैं}}','The current begins “नहीं {type} अनुरोध”; this supplies natural no/remaining agreement.'),
'id':('{remaining, plural, =0 {Tidak ada} other {<strong>#</strong>}} {remaining, plural, one {permintaan {type} tersisa} other {permintaan {type} tersisa}}','The current “Tidak {type} ... sisa” is incomplete Indonesian.'),
'ja':('{remaining, plural, =0 {残りの{type}リクエストはありません} other {残り<strong>#</strong>件の{type}リクエストがあります}}{remaining, plural, one {} other {}}','The current zero branch says remaining requests without saying none remain.'),
'pt_BR':('{remaining, plural, =0 {Nenhum} other {<strong>#</strong>}} {remaining, plural, =0 {pedido de {type} restante} one {pedido de {type} restante} many {pedidos de {type} restantes} other {pedidos de {type} restantes}}','The current places {type} before pedido; this uses natural order and agreement.'),
'vi':('{remaining, plural, =0 {Không còn} other {Còn <strong>#</strong>}} {remaining, plural, one {yêu cầu} other {yêu cầu}} {type}','The current word order is awkward; put the request noun before its category and state zero naturally.'),
'zh_Hans':('{remaining, plural, =0 {没有剩余的{type}} other {还剩<strong>#</strong>个{type}}}{remaining, plural, one {请求} other {请求}}','The current word order reads unnaturally; this gives a natural no/count form and keeps the source variables.'),
'zh_Hant':('{remaining, plural, =0 {沒有剩餘的{type}} other {還剩<strong>#</strong>個{type}}}{remaining, plural, one {請求} other {請求}}','The current word order reads unnaturally; this gives a natural no/count form and keeps the source variables.')
}
for loc,(target,why) in rr.items(): add(3009,loc,target,'correction',why)

rq={
'de':('Du musst mindestens <strong>{seasons}</strong> {seasons, plural, one {Staffelanfrage} other {Staffelanfragen}} übrig haben, um eine Anfrage für diese Serie einzureichen.','correction','Use the compound Staffelanfrage; the current split compound is unidiomatic.'),
'hi':('इस श्रृंखला के लिए अनुरोध भेजने हेतु आपके पास कम से कम <strong>{seasons}</strong> {seasons, plural, one {सीज़न अनुरोध} other {सीज़न अनुरोध}} शेष होने चाहिए।','refinement','The current Hindi word order is difficult to parse; this makes the quota and action clear.'),
'pt_BR':('Você precisa ter ao menos <strong>{seasons}</strong> {seasons, plural, one {solicitação de temporada restante} other {solicitações de temporada restantes}} para poder enviar uma solicitação para esta série.','correction','The current says requests for the series; the counted items are season requests.'),
'vi':('Bạn cần còn ít nhất <strong>{seasons}</strong> {seasons, plural, one {yêu cầu mùa} other {yêu cầu mùa}} để gửi yêu cầu cho loạt phim này.','refinement','Make the remaining quota before the action easier to parse.'),
'zh_Hans':('要提交该剧集的申请，你至少还需有 <strong>{seasons}</strong> 个{seasons, plural, one {剧季请求} other {剧季请求}}。','correction','季节请求 means seasonal/weather requests; the caller needs requests for a TV-series season.'),
'zh_Hant':('若要提交此影集的申請，您至少還需有 <strong>{seasons}</strong> 個{seasons, plural, one {影集季請求} other {影集季請求}}。','correction','季节要求 means seasonal/weather requests; the caller needs requests for a TV-series season.')
}
for pos in (3010,3011):
    for loc,(target,verdict,why) in rq.items():
        if pos==3011:
            if loc=='de': target=target.replace('Du musst','Dieser Benutzer muss',1)
            if loc=='hi': target=target.replace('आपके पास','इस उपयोगकर्ता के पास',1)
            if loc=='pt_BR': target=target.replace('Você precisa','Esse usuário precisa',1)
            if loc=='vi': target=target.replace('Bạn cần','Người dùng này cần',1)
            if loc=='zh_Hans': target=target.replace('你至少还需','此用户至少还需',1)
            if loc=='zh_Hant': target=target.replace('您至少還需','此使用者至少還需',1)
        add(pos,loc,target,verdict,why)
add(3012,'zh_Hans','剧季','refinement','Use a TV-series season label rather than a season-count phrase.')
add(3012,'zh_Hant','影集季','refinement','Use a TV-series season label rather than a season-count phrase.')
add(3013,'zh_Hans','{limit, plural, one {剧季} other {剧季}}','correction','季节 means weather season; this is a TV-series season quota.')

sw={
'de':('{remaining, plural, one {Eine Softwareanfrage ist noch übrig} other {# Softwareanfragen sind noch übrig}}','Softwareanforderung means a software requirement, not a user request.'),
'hi':('{remaining, plural, one {एक सॉफ़्टवेयर अनुरोध शेष है} other {# सॉफ़्टवेयर अनुरोध शेष हैं}}','The current plural branch says requests continue; this states the remaining count naturally.'),
'id':('{remaining, plural, one {Satu permintaan perangkat lunak tersisa} other {# permintaan perangkat lunak tersisa}}','Tetap suggests remaining fixed; use tersisa for a quota.'),
'vi':('{remaining, plural, one {Còn lại một yêu cầu phần mềm} other {Còn lại # yêu cầu phần mềm}}','The current plural branch is awkward and capitalized mid-sentence.'),
'zh_Hans':('{remaining, plural, one {还剩一个软件请求} other {还剩 # 个软件请求}}','The current says the request remains unchanged; this says it remains available.'),
'zh_Hant':('{remaining, plural, one {還剩一個軟體請求} other {還剩 # 個軟體請求}}','The current says the request is retained; this says it remains available.')
}
for loc,(target,why) in sw.items(): add(3015,loc,target,'correction',why)
add(3016,'de','{limit, plural, one {Softwareanfrage} other {Softwareanfragen}}','correction','Softwareanforderung means a software requirement.')
add(3016,'es','{limit, plural, one {solicitud de software} many {solicitudes de software} other {solicitudes de software}}','refinement','Lowercase the noun label after the numeric limit.')
add(3016,'pt_BR','{limit, plural, one {pedido de software} many {pedidos de software} other {pedidos de software}}','refinement','Lowercase the noun label after the numeric limit.')
for p,l,t,v,w in [
(3017,'ja','承認が必要','refinement','Remove unnatural spacing in this status label.'),
(3017,'ko','승인이 필요함','correction','The current leaves Required in English.'),
(3017,'vi','Cần phê duyệt','correction','The current says the request was approved, reversing Approval Required.'),
(3017,'pt_BR','Aprovação necessária','refinement','Remove the sentence-ending period from this short status label.'),
(3018,'ja','自動的に','correction','The key is the adverb Automatically; the current loanword is an adjective/noun.'),
(3018,'pt_BR','Automaticamente','refinement','Remove the sentence-ending period from this one-word label.'),
(3019,'ja','リクエスト済み','correction','The current is only the noun request, not the requested status.'),
(3019,'zh_Hans','已请求','correction','The current is only the noun request, not the requested status.'),
(3019,'zh_Hant','已提出請求','correction','The current is only the noun request, not the requested status.'),
(3020,'ar','تعذّر تحميل الحلقات','correction','The current Arabic says the episodes cannot be loved, not that loading failed.'),
(3020,'ko','에피소드를 불러올 수 없습니다','correction','The current Korean is mixed with English and does not state the load error.'),
(3021,'ar','تم الاحتفاظ باختيار طلبك. حمّل معلومات المواسم كاملة قبل تغييره.','correction','The current sentence is ungrammatical and does not clearly preserve the request selection.'),
(3021,'de','Ihre Auswahl der Anfrage bleibt erhalten. Laden Sie alle Informationen zu den Staffeln, bevor Sie sie ändern.','refinement','Use the TV-season term Staffeln and make before changing explicit.'),
(3021,'id','Pilihan permintaan Anda tetap tersimpan. Muat semua informasi musim sebelum mengubahnya.','correction','Diawetkan is used for preserved food/things; tetap tersimpan fits a saved selection.'),
(3021,'ja','リクエストの選択内容は保持されています。変更する前に、すべてのシーズン情報を読み込んでください。','correction','The current states that the season data will load instead of instructing the user to load it before changing the selection.'),
(3021,'ko','요청 선택 내용은 유지됩니다. 변경하기 전에 모든 시즌 정보를 불러오세요.','correction','Use 시즌 for TV seasons rather than 계절 (weather season).'),
(3021,'vi','Lựa chọn yêu cầu của bạn được giữ nguyên. Hãy tải toàn bộ thông tin về các mùa trước khi thay đổi lựa chọn.','correction','The current uses an unsuitable pronoun and a verb meaning preserve food.'),
(3021,'zh_Hans','您的请求选择已保留。更改前请加载全部剧季信息。','correction','Use the TV-season term and remove extra spaces before punctuation.'),
(3021,'zh_Hant','您的要求選擇已保留。變更前請載入所有影集季資訊。','correction','Use the TV-season term and remove extra spaces before punctuation.'),
(3022,'ar','جارٍ تحميل الحلقات','correction','The current is a mistransliteration, not “episodes are loading.”'),
(3022,'hi','एपिसोड लोड हो रहे हैं','refinement','Complete the terse “episodes load” phrase as a natural loading state.'),
(3022,'id','Memuat episode','correction','The current misspells episode as episoda.'),
(3022,'ja','エピソードを読み込み中…','correction','The current is an unnatural “loading of episode” phrase.'),
(3022,'ko','에피소드를 불러오는 중…','correction','The current omits what is loading.'),
(3022,'vi','Đang tải các tập…','refinement','Use the common UI verb tải and make the episode plurality clear.'),
(3022,'zh_Hans','正在加载剧集','correction','The current literally loads entries; use the TV episode term.'),
(3022,'zh_Hant','正在載入各集','correction','Use the TV episode term for this loading state.'),
(3023,'zh_Hans','没有可用的剧季','refinement','Make explicit that unavailable seasons belong to a series.'),
(3023,'zh_Hant','沒有可用的影集季','correction','The current says no season count is available, not no TV seasons.'),
(3024,'hi','अपने अनुरोध चयन को बदले बिना सीज़न और एपिसोड फिर से लोड करें।','correction','The current says to view the seasons and episodes again; the tooltip fetches them again.'),
(3024,'id','Muat ulang musim dan episode tanpa mengubah pilihan permintaan Anda.','refinement','Use the standard episode spelling and the UI reload verb.'),
(3024,'ja','リクエストの選択内容を変更せずに、シーズンとエピソードを再取得します。','refinement','Replace the awkward technical loanword フェッチ with 再取得.'),
(3024,'ko','요청 선택을 변경하지 않고 시즌과 에피소드를 다시 불러오세요.','correction','The current verb means bundle/pack again, not fetch/load.'),
(3024,'pt_BR','Busque as temporadas e os episódios novamente sem alterar sua seleção de solicitação.','correction','Estações means stations/seasons of the year; TV seasons are temporadas.'),
(3024,'vi','Tải lại các mùa và tập phim mà không thay đổi lựa chọn yêu cầu của bạn.','refinement','The current collect verb and word order are awkward for a reload tooltip.'),
(3024,'zh_Hans','在不更改请求选择的情况下，重新获取所有剧季和剧集。','refinement','Use series-season wording and remove the extra punctuation space.'),
(3024,'zh_Hant','在不變更請求選擇的情況下，重新擷取所有影集季與各集。','refinement','Use series-season wording and remove the extra punctuation space.'),
(3027,'ar','بلا عنوان','correction','غير مترجم means untranslated, not untitled.'),
(3027,'ja','無題','correction','未定 means undecided; 無題 means untitled.'),
(3028,'pt_BR','Não foi possível encontrar uma correspondência para esta série.','correction','The current has a gender error and repeats série.'),
(3028,'vi','Chúng tôi không tìm thấy kết quả phù hợp cho bộ phim này.','correction','Chuỗi means string/chain, not a television series.'),
(3028,'zh_Hans','找不到与此剧集匹配的项目。','refinement','Restore the source meaning of not finding a matching result.'),
(3028,'zh_Hant','找不到符合此影集的項目。','refinement','Restore the source meaning of not finding a matching result.'),
(3029,'es','No hemos podido encontrar automáticamente una coincidencia para esta serie. Seleccione la coincidencia correcta a continuación.','correction','The current says the request could not match and mixes informal tu with formal seleccione.'),
(3029,'fr','Nous n’avons pas pu associer cette série automatiquement. Veuillez sélectionner la correspondance correcte dans la liste ci-dessous.','refinement','Use correspondance for the matching result instead of association.'),
(3029,'id','Kami tidak dapat mencocokkan seri ini secara otomatis. Silakan pilih hasil yang sesuai di bawah ini.','refinement','Pasangan yang benar means a correct pair; hasil yang sesuai is a natural matching result.'),
(3029,'ja','このシリーズを自動で照合できませんでした。以下から正しい候補を選択してください。','correction','The current attempts to match the request rather than the series itself.'),
(3029,'pt_BR','Não foi possível encontrar automaticamente uma correspondência para esta série. Selecione a correspondência correta abaixo.','correction','The current says it could not correlate your request instead of matching the series.'),
(3029,'vi','Chúng tôi không thể tự động tìm kết quả phù hợp cho loạt phim này. Hãy chọn kết quả chính xác bên dưới.','correction','Chuỗi means string/chain, not a television series.'),
(3031,'ar','علامة صح خضراء فاتحة: متاحة بالكامل. علامة صح خضراء داكنة: متاحة جزئيًا. علامة X حمراء: غير متاحة.','correction','الشيك means bank cheque/check, not a visual checkmark.'),
(3031,'fr','Coche vert clair : entièrement disponible. Coche vert foncé : partiellement disponible. Croix rouge : indisponible.','correction','Contrôle is not the checkmark icon in this legend.'),
(3031,'hi','चमकीला हरा चेकमार्क: पूरी तरह उपलब्ध। गहरा हरा चेकमार्क: आंशिक रूप से उपलब्ध। लाल X: उपलब्ध नहीं।','refinement','Replace English color words transliterated in the current with Hindi equivalents.'),
(3031,'ja','明るい緑のチェックマーク: 完全に利用可能。濃い緑のチェックマーク: 一部利用可能。赤い X: 利用不可。','correction','点検 means inspection; this legend describes a checkmark symbol.'),
(3031,'ko','밝은 초록색 체크 표시: 완전히 이용 가능. 진한 초록색 체크 표시: 일부 이용 가능. 빨간색 X: 이용 불가.','correction','The current says valid instead of available and is unidiomatic.'),
(3031,'pt_BR','Marca de verificação verde-clara: totalmente disponível. Marca de verificação verde-escura: parcialmente disponível. X vermelho: indisponível.','correction','Cheque means a bank cheque, not a checkmark icon.'),
(3031,'vi','Dấu tích màu xanh lá nhạt: hoàn toàn khả dụng. Dấu tích màu xanh lá đậm: khả dụng một phần. Dấu X màu đỏ: không khả dụng.','correction','Kiểm tra means an inspection/check, not the checkmark icon.'),
(3031,'zh_Hans','亮绿色勾号：完全可用。深绿色勾号：部分可用。红色X：不可用。','correction','检查 means inspect/check; the source describes a checkmark symbol.'),
(3031,'zh_Hant','亮綠色勾號：完全可用。深綠色勾號：部分可用。紅色X：不可用。','correction','檢查 means inspect/check; the source describes a checkmark symbol.'),
(3032,'ar','إلغاء تحديد جميع الحلقات','correction','The caller is a selection toggle; state deselection rather than cleaning episodes.'),
(3032,'de','Auswahl aller Episoden aufheben','correction','The caller is a selection toggle; löschen can imply deleting episode data.'),
(3032,'es','Quitar la selección de todos los episodios','refinement','Make the clear-selection action explicit.'),
(3032,'fr','Désélectionner tous les épisodes','refinement','Make the clear-selection action explicit.'),
(3032,'hi','सभी एपिसोड का चयन हटाएँ','refinement','Make the clear-selection action explicit.'),
(3032,'id','Batalkan pilihan semua episode','correction','Hapus can imply deleting episodes; the caller clears the selection.'),
(3032,'ja','すべてのエピソードの選択を解除','refinement','Make the clear-selection action explicit.'),
(3032,'ko','모든 에피소드 선택 해제','correction','The current does not clearly say to clear the selection.'),
(3032,'pt_BR','Desmarcar todos os episódios','refinement','Make the clear-selection action explicit.'),
(3032,'vi','Bỏ chọn tất cả các tập','correction','Xoá can imply deleting episodes; the caller clears the selection.'),
(3032,'zh_Hans','取消选择所有剧集','correction','事件 means events, and the action clears selected episodes.'),
(3032,'zh_Hant','取消選取所有集','refinement','Make the clear-selection action explicit.'),
(3033,'ar','إلغاء تحديد جميع المواسم','correction','The caller clears the selected seasons; the current says to clean seasons.'),
(3033,'de','Alle Staffeln abwählen','refinement','This is already a clear selection label; retain the TV-season term.'),
(3033,'es','Quitar la selección de todas las temporadas','refinement','Make the clear-selection action explicit.'),
(3033,'fr','Désélectionner toutes les saisons','refinement','Make the clear-selection action explicit.'),
(3033,'hi','सभी सीज़न का चयन हटाएँ','correction','Use the TV-season term and state deselection.')
]: add(p,l,t,v,w)

ca={
'ar':'إلغاء تحديد الحلقة {number, number}','de':'Auswahl von Folge {number, number} aufheben','es':'Deseleccionar el episodio {number, number}',
'fr':'Désélectionner l’épisode {number, number}','hi':'एपिसोड {number, number} का चयन हटाएँ','id':'Batalkan pilihan episode {number, number}',
'ja':'エピソード {number, number} の選択を解除','ko':'에피소드 {number, number} 선택 해제','pt_BR':'Desmarque o episódio {number, number}',
'vi':'Bỏ chọn tập {number, number}','zh_Hans':'取消选择第 {number, number} 集','zh_Hant':'取消選取第 {number, number} 集'}
for l,t in ca.items(): add(3034,l,t,'correction','Pinned selected-versus-select caller branch shows this removes the episode from the request selection; preserve the number formatter.')
cs={
'ar':'إلغاء تحديد الموسم {number, number}','de':'Auswahl von Staffel {number, number} aufheben','es':'Deseleccionar la temporada {number, number}',
'fr':'Désélectionner la saison {number, number}','hi':'सीज़न {number, number} का चयन हटाएँ','id':'Batalkan pilihan musim {number, number}',
'ja':'シーズン {number, number} の選択を解除','ko':'시즌 {number, number} 선택 해제','pt_BR':'Desmarque a temporada {number, number}',
'vi':'Bỏ chọn mùa {number, number}','zh_Hans':'取消选择第 {number, number} 季','zh_Hant':'取消選取第 {number, number} 季'}
for l,t in cs.items(): add(3035,l,t,'correction','Pinned seasonSelection-versus-select caller branch shows this removes the season from the request selection; preserve the number formatter.')
csp={
'ar':'إلغاء تحديد الحلقات الخاصة','de':'Auswahl der Sonderfolgen aufheben','es':'Deseleccionar los episodios especiales',
'fr':'Désélectionner les épisodes spéciaux','hi':'विशेष एपिसोड का चयन हटाएँ','id':'Batalkan pilihan episode spesial',
'ja':'スペシャル回の選択を解除','ko':'스페셜 에피소드 선택 해제','pt_BR':'Desmarcar episódios especiais',
'vi':'Bỏ chọn các tập đặc biệt','zh_Hans':'取消选择特别篇','zh_Hant':'取消選取特別篇'}
for l,t in csp.items(): add(3036,l,t,'correction','The source clears the selected Specials category in the episode selector; state the selection change rather than deleting episodes.')
for p,l,t,v,w in [
(3038,'ar','الحلقة {number}','correction','The current inserts الرابعة (fourth), which is not in the source.'),
(3038,'ko','에피소드 {number}','correction','인기있는 means popular, not episode.'),
(3038,'vi','Tập {number}','correction','Chương means chapter; this is a TV episode.'),
(3038,'zh_Hans','第 {number} 集','correction','诗集 means poetry collection, not a TV episode.'),
(3040,'ar','تعذّر تحميل الحلقات. حاول اختيار الموسم مرة أخرى.','correction','الأوعية means vessels/containers, not episodes.'),
(3040,'hi','एपिसोड लोड नहीं हो सके। सीज़न को फिर से चुनने की कोशिश करें।','correction','Use the TV-series term सीज़न rather than मौसम (weather season).'),
(3040,'id','Episode tidak dapat dimuat. Coba pilih musim lagi.','correction','Fix the episode misspelling and keep the same-season retry instruction.'),
(3040,'ja','エピソードを読み込めませんでした。シーズンをもう一度選択してください。','correction','The current loading verb is ungrammatical and uses the weather-season term.'),
(3040,'ko','에피소드를 불러오지 못했습니다. 시즌을 다시 선택해 보세요.','correction','Fix spacing and use the TV-series season term.'),
(3040,'pt_BR','Não foi possível carregar os episódios. Tente selecionar a temporada novamente.','refinement','Use the natural UI form for the load failure and retry instruction.'),
(3040,'vi','Không thể tải các tập. Hãy thử chọn lại mùa.','correction','The current says files and suggests another season instead of retrying this season.'),
(3040,'zh_Hans','无法加载剧集。请尝试重新选择该季。','correction','The current says a complete set could not load; name episodes and retry the same season.'),
(3040,'zh_Hant','無法載入各集。請再選一次該季。','correction','The current repeats 集 and uses awkward wording.'),
(3042,'hi','सीज़न {number}','correction','Use the TV-season term, not मौसम (weather season).'),
(3043,'id','Pilih semua episode','correction','The current misspells episode as episoda.'),
(3043,'zh_Hans','选择所有剧集','correction','事件 means events, not TV episodes.'),
(3043,'zh_Hant','選取所有集','refinement','片段 means clips/fragments; use the episode term.'),
(3044,'hi','सभी सीज़न चुनें','correction','Use the TV-season term rather than मौसम.'),
(3044,'ja','すべてのシーズンを選択','correction','Use シーズン for TV seasons; 季節 means seasons of the year.'),
(3044,'pt_BR','Selecione todas as temporadas','correction','Estações means stations/seasons of the year; TV seasons are temporadas.'),
(3044,'zh_Hans','选择所有剧季','correction','Use the TV-season term rather than weather seasons.'),
(3044,'zh_Hant','選擇所有影集季','refinement','Make clear that the selectable units are series seasons.'),
(3045,'ko','에피소드 {number, number} 선택','correction','The current reads as “selected episode”; put the action after the number.'),
(3045,'pt_BR','Selecione o episódio {number, number}','refinement','Add the article before episódio.'),
(3046,'hi','एपिसोड देखने के लिए कोई सीज़न चुनें।','correction','Use the TV-season term rather than मौसम.'),
(3046,'ja','エピソードを表示するには、シーズンを選択してください。','correction','四季折々 means in each season, reversing the instruction.'),
(3046,'vi','Chọn một mùa để xem các tập phim của mùa đó.','refinement','Make the referent of “its episodes” explicit.'),
(3046,'zh_Hans','选择一个剧季以查看其中的剧集。','refinement','Use explicit TV-season/episode terms and remove the punctuation space.'),
(3046,'zh_Hant','選擇一季以查看其中的各集。','correction','片段 means clips/fragments rather than episodes.'),
(3047,'zh_Hans','选择第 {number, number} 季','correction','季節 means weather season; this is a TV-season selector.'),
(3047,'zh_Hant','選擇第 {number, number} 季','correction','季節 means weather season; this is a TV-season selector.'),
(3048,'ko','스페셜 에피소드 선택','correction','특수 means technical/special, not the Specials episode category.'),
(3048,'pt_BR','Selecionar episódios especiais','correction','Especialidades means specialties, not special episodes.'),
(3048,'vi','Chọn các tập đặc biệt','correction','The current omits the episode noun.'),
(3048,'zh_Hans','选择特别篇','correction','Name the Specials category rather than the adjective special.'),
(3048,'zh_Hant','選擇特別篇','correction','Name the Specials category rather than the adjective special.')
]: add(p,l,t,v,w)
for loc,target,verdict in [
('ar','إلغاء تحديد جميع المواسم','correction'),('de','Alle Staffeln abwählen','refinement'),
('es','Quitar la selección de todas las temporadas','refinement'),('fr','Désélectionner toutes les saisons','refinement'),
('hi','सभी सीज़न का चयन हटाएँ','correction'),('id','Batalkan pilihan semua musim','refinement'),
('ja','すべてのシーズンの選択を解除','refinement'),('ko','모든 시즌 선택 해제','correction'),
('pt_BR','Desmarcar todas as temporadas','refinement'),('vi','Bỏ chọn tất cả các mùa','correction'),
('zh_Hans','取消选择所有剧季','correction'),('zh_Hant','取消選取所有影集季','refinement')]:
    add(3033,loc,target,verdict,'The selector caller clears selected seasons; state the selection action and use TV-season wording.')

# Ensure no output files are being overwritten.
for f in [ROWS_OUT,SUMMARY_OUT,ATTEST_OUT,README_OUT,MANIFEST_OUT,SUMS_OUT]:
    assert not f.exists(), f'output already exists: {f}'

# Verify all listed inputs, exact live PR and tree, and the parent exact-head attestation.
sums_path=P/'INPUT-SHA256SUMS'
assert sha(sums_path.read_bytes())==SUMS_SHA
input_checks=[]
for line in sums_path.read_text().splitlines():
    expected,name=line.split(None,1); name=name.strip().lstrip('*')
    actual=sha((P/name).read_bytes()); assert actual==expected,(name,expected,actual)
    input_checks.append({'path':name,'sha256':actual,'matches':True})
assert sha(CELLS.read_bytes())==CELLS_SHA and sha(CALLERS.read_bytes())==CALLERS_SHA
assert sha(TRIAGE.read_bytes())==TRIAGE_SHA and sha(HEAD_REPORT.read_bytes())==HEAD_REPORT_SHA
assert sha(PROPOSALS.read_bytes())==PROPOSALS_SHA
hr=readj(HEAD_REPORT)
assert hr['exactHead']==HEAD and hr['exactTree']==TREE and hr['sourceCurrentCellMismatches']==0
assert hr['all12CatalogsMatchOldPin'] is True and hr['callerFilesChecked']==21 and hr['callerLinesChecked']==649
pr=json.loads(subprocess.check_output(['gh','pr','view','418','--repo','snapetech-org/seerrng','--json','state,isDraft,headRefOid,headRefName,url'],text=True))
assert pr['headRefOid']==HEAD and pr['state']=='OPEN' and pr['isDraft'] is True
commit=json.loads(subprocess.check_output(['gh','api',f'repos/snapetech-org/seerrng/git/commits/{HEAD}'],text=True))
assert commit['tree']['sha']==TREE
remote_lines=subprocess.check_output(['git','ls-remote','https://github.com/snapetech-org/seerrng.git',f"refs/heads/{pr['headRefName']}",'refs/pull/418/head'],text=True).splitlines()
remote={x.split('\t')[1]:x.split('\t')[0] for x in remote_lines}
assert remote[f"refs/heads/{pr['headRefName']}"]==HEAD and remote['refs/pull/418/head']==HEAD

cells=readjl(CELLS)
contexts=readjl(CALLERS)
primary_proposals=readjl(PROPOSALS)
assert len(primary_proposals)==320
proposal_by_key={(x['sourcePosition'],x['locale']):x for x in primary_proposals}
assert len(proposal_by_key)==len(primary_proposals)
assert all(x['exactHead']==HEAD and x['exactTree']==TREE for x in primary_proposals)
triage=readj(TRIAGE)
assert len(cells)==1200 and len(contexts)==100
slice_rows=[x for x in cells if 3000<=x['sourcePosition']<=3049]
assert len(slice_rows)==600 and len({x['sourceId'] for x in slice_rows})==50
assert {x['locale'] for x in slice_rows}==set(LOCALES)
assert len({(x['sourceId'],x['locale']) for x in slice_rows})==600
assert all(x['exactHead']==HEAD and x['exactTree']==TREE for x in slice_rows)
ctx_by_id={x['sourceId']:x for x in contexts}
triage_holds={x['sourceId']:x for x in triage['unmappedHoldSources']}
alias_ids={x['sourceId'] for x in triage['aliasRepairs']}
assert len(alias_ids)==8 and len(triage_holds)==3
assert 'components.RequestModal.QuotaDisplay.magazinelimit' in triage_holds

def brace_ok(s):
    depth=0
    for ch in s:
        if ch=='{': depth+=1
        elif ch=='}':
            depth-=1
            if depth<0: return False
    return depth==0
def vars_in(s,known=None):
    found=set(re.findall(r'\{([A-Za-z_][A-Za-z0-9_]*)',s))
    return found if known is None else found & set(known)
def tags_in(s): return re.findall(r'</?[A-Za-z][^>]*>',s)
def tags_balanced(s):
    stack=[]
    for t in tags_in(s):
        m=re.fullmatch(r'<(/?)([A-Za-z][A-Za-z0-9]*)(?:\s[^>]*)?>',t)
        if not m: return False
        close,name=m.groups()
        if close:
            if not stack or stack.pop()!=name: return False
        else: stack.append(name)
    return not stack
def selectors_in(s): return set(re.findall(r'(?<!\w)(?:=\d+|zero|one|two|few|many|other)(?=\s*\{)',s))
def structural(source,current,candidate,protected,source_vars):
    srcv=set(source_vars); curv=vars_in(current,srcv); candv=vars_in(candidate,srcv) if candidate is not None else None
    srct=tags_in(source); curt=tags_in(current); candt=tags_in(candidate) if candidate is not None else None
    srcsel=selectors_in(source); cursel=selectors_in(current); candsel=selectors_in(candidate) if candidate is not None else None
    current_ok=(brace_ok(source) and brace_ok(current) and srcv.issubset(curv)
      and brace_ok(source) and tags_balanced(source) and tags_balanced(current)
      and set(curt).issubset(set(srct)) and srcsel.issubset(cursel)
      and set(protected).issubset(curv))
    candidate_ok=True if candidate is None else (brace_ok(candidate) and srcv.issubset(candv)
      and tags_balanced(candidate) and set(candt).issubset(set(srct))
      and srcsel.issubset(candsel) and set(protected).issubset(candv))
    return {'currentBraceBalance':brace_ok(current),'candidateBraceBalance':brace_ok(candidate) if candidate is not None else None,
      'sourceVariableNames':sorted(srcv),'currentVariableNames':sorted(curv),'candidateVariableNames':sorted(candv) if candv is not None else None,
      'requiredVariablesPresent':srcv.issubset(curv),'candidateRequiredVariablesPresent':srcv.issubset(candv) if candv is not None else None,
      'sourceIcuSelectors':sorted(srcsel),'currentIcuSelectors':sorted(cursel),'candidateIcuSelectors':sorted(candsel) if candsel is not None else None,
      'requiredIcuSelectorsPresent':srcsel.issubset(cursel),'candidateRequiredIcuSelectorsPresent':srcsel.issubset(candsel) if candsel is not None else None,
      'sourceMarkupTokens':srct,'currentMarkupBalanced':tags_balanced(current),'candidateMarkupBalanced':tags_balanced(candidate) if candidate is not None else None,
      'currentMarkupUsesOnlySourceTags':set(curt).issubset(set(srct)),'candidateMarkupUsesOnlySourceTags':set(candt).issubset(set(srct)) if candt is not None else None,
      'protectedPlaceholderNames':sorted(protected),'protectedPlaceholdersPresent':set(protected).issubset(curv),
      'candidateProtectedPlaceholdersPresent':set(protected).issubset(candv) if candv is not None else None,
      'reportedInputPlaceholderParity':None,'reportedInputMarkupParity':None,
      'branchAwareNote':'Plural alternatives may repeat placeholders and <strong> tags without changing the rendered-path contract; Korean 3009 nests type in mutually exclusive branches. Raw counts are not treated as failures.',
      'allRequiredChecksPass':current_ok and candidate_ok}

records=[]
counts=collections.Counter()
proposal_reviews=collections.Counter()
src_counts=collections.Counter()
for cell in sorted(slice_rows,key=lambda x:(x['sourcePosition'],LOCALES.index(x['locale']))):
    pos,loc=cell['sourcePosition'],cell['locale']
    source,source_id,current=cell['source'],cell['sourceId'],cell['currentTarget']
    assert current is not None and sha(source)==cell['sourceTextSha256'] and sha(current)==cell['currentTargetHash']
    ctx=ctx_by_id[source_id]
    ctx_hash=canonical_sha(ctx)
    assert ctx_hash==cell['callerContextSha256'],(source_id,loc,ctx_hash,cell['callerContextSha256'])
    pins=[]
    for pin in ctx.get('pinnedLineRefs',[]):
        assert pin['lineSha256'] in cell['callerPinnedLineHashes'],(source_id,pin)
        pins.append({'file':pin['file'],'line':pin['line'],'lineText':pin['lineText'],'lineSha256':pin['lineSha256'],
                     'previousLine':pin.get('previousLine'),'nextLine':pin.get('nextLine')})
    caller_files=[{'path':x['path'],'fileSha256':x['fileSha256'],'gitBlob':x['blob']} for x in ctx.get('callerFiles',[])]
    d=D.get((pos,loc),{'target':None,'verdict':'accept-current',
        'why':'Current target preserves the source meaning for the exact caller context; no change recommended in this independent machine-assisted review.',
        'confidence':'moderate'})
    primary=proposal_by_key.get((pos,loc))
    primary_review={'disposition':'none','target':None,'targetHash':None,'finalTarget':None,'rationale':None}
    candidate=d['target']; verdict=d['verdict']; rationale=d['why']; confidence=d['confidence']
    if primary:
        assert primary['sourceId']==source_id and primary['source']==source
        assert primary['sourceTextSha256']==cell['sourceTextSha256']
        assert primary['currentTarget']==current and primary['currentTargetHash']==cell['currentTargetHash']
        assert primary['callerContextSha256']==ctx_hash and primary['targetHash']==sha(primary['target'])
        if pos==3011 and loc=='es':
            candidate='Para que este usuario pueda solicitar esta serie, debe tener al menos <strong>{seasons}</strong> {seasons, plural, one {solicitud de temporada restante} many {solicitudes de temporada restantes} other {solicitudes de temporada restantes}}.'
            verdict='correction'
            rationale='Revise the proposal to preserve “this user”; the submitted target is identical to the general-user 3010 string and omits the user subject.'
            confidence='moderate'
            primary_review={'disposition':'revise','target':primary['target'],'targetHash':primary['targetHash'],
              'finalTarget':candidate,'rationale':'The primary proposal drops the explicit user subject. The revised target names este usuario.'}
        else:
            candidate=primary['target']
            verdict=primary['kind']
            rationale='Accepted after independent caller and structural review; the target corrects or refines the pinned current translation.'
            confidence='moderate'
            primary_review={'disposition':'accept','target':primary['target'],'targetHash':primary['targetHash'],
              'finalTarget':candidate,'rationale':'Preserves source meaning in its pinned caller context and passes the independent structural checks.'}
        proposal_reviews[primary_review['disposition']]+=1
    if pos==3001:
        assert verdict=='hold' and ctx['callerUseStatus']=='definition-only-or-single-reference'
    if source_id in alias_ids:
        assert ctx['callerUseStatus']=='direct-or-helper-reference-found'
    st=structural(source,current,candidate,cell['protectedLiterals'],[x['name'] for x in cell['sourcePlaceholders']])
    st['reportedInputPlaceholderParity']=cell['placeholderParity']; st['reportedInputMarkupParity']=cell['markupParity']
    if pos==3009:
        st['rawExtractorLimitation']='Input-level counts report Korean placeholder mismatch and six markup-count mismatches. The Korean type appears once in each exclusive plural branch; strong tags repeat only in numeric branches. The structural review checks variable names, selectors, brace balance, and tag balance rather than raw totals.'
    assert st['allRequiredChecksPass'],(pos,loc,st)
    source_location={'file':cell['sourceFile'],'fileSha256':cell['sourceFileSha256'],'gitBlob':cell['sourceCatalogBlob'],
                     'sourcePosition':pos,'sourceTextSha256':cell['sourceTextSha256']}
    hold_evidence=None
    if source_id in triage_holds:
        hold=triage_holds[source_id]
        ep=hold['sourceEnglishLocation']
        source_location.update({'line':ep['line'],'lineText':ep['lineText'],'lineSha256':ep['lineSha256']})
        adjacent=hold.get('callerGapEvidence',{}).get('adjacentCallerEvidence',{})
        hold_evidence={'triageArtifact':TRIAGE.name,'triageArtifactSha256':TRIAGE_SHA,
          'classification':hold.get('classification'),'exactHeadSearch':hold.get('callerGapEvidence',{}).get('exactHeadSearch'),
          'definitionPins':hold.get('callerPins',[]),'adjacentCallerEvidence':adjacent,
          'recommendation':hold.get('recommendation')}
        for pin in adjacent.get('pins',[]):
            pins.append({'file':adjacent.get('file'),'line':pin['line'],'lineText':pin['lineText'],
                         'lineSha256':pin['lineSha256'],'role':'adjacent quota chooser evidence'})
    record={
      'schemaVersion':1,'reviewer':'independent-machine-assisted-exact-head-cross-review',
      'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,
      'sourcePosition':pos,'sourceId':source_id,'source':source,'sourceHash':cell['sourceHash'],
      'sourceTextSha256':cell['sourceTextSha256'],'sourceLocation':source_location,
      'locale':loc,'catalogPath':cell['localeFile'],'catalogFileSha256':cell['localeFileSha256'],'catalogGitBlob':cell['localeBlob'],
      'currentTarget':current,'currentTargetHash':cell['currentTargetHash'],
      'inputDisposition':cell['disposition'],'inputPriorDisposition':cell['priorDisposition'],
      'primaryProposalAvailable':primary is not None,'primaryProposalReview':primary_review,
      'independentVerdict':verdict,'candidateTarget':candidate,
      'candidateTargetSha256':sha(candidate) if candidate is not None else None,'rationale':rationale,'confidence':confidence,
      'callerContextRef':cell['callerContextRef'],'callerContextSha256':ctx_hash,
      'callerContextOriginalSha256':cell.get('callerContextSha256Original'),
      'callerContextArtifact':{'path':CALLERS.name,'sha256':CALLERS_SHA},
      'callerUseStatus':ctx['callerUseStatus'],'callerEvidenceNote':ctx['callerEvidenceNote'],
      'callerFiles':caller_files,'callerPins':pins,'callerScopeLimit':ctx.get('callerEvidenceNote'),'holdEvidence':hold_evidence,
      'placeholderMarkupIcuProtectedLiteralChecks':st,
      'holdRationale':rationale if verdict=='hold' else None,'nativeSpeakerApproval':False
    }
    records.append(record); counts[verdict]+=1
    src_counts[pos]+=1
assert len(records)==600 and counts['hold']==12
assert all(src_counts[p]==12 for p in range(3000,3050))
assert not [x for x in records if x['sourcePosition'] in range(3020,3028) and x['independentVerdict']=='hold']

# Verify PR head/tree still match just before packet creation.
pr_end=json.loads(subprocess.check_output(['gh','pr','view','418','--repo','snapetech-org/seerrng','--json','state,isDraft,headRefOid,headRefName,url'],text=True))
commit_end=json.loads(subprocess.check_output(['gh','api',f"repos/snapetech-org/seerrng/git/commits/{HEAD}"],text=True))
remote_end_lines=subprocess.check_output(['git','ls-remote','https://github.com/snapetech-org/seerrng.git',f"refs/heads/{pr_end['headRefName']}",'refs/pull/418/head'],text=True).splitlines()
remote_end={x.split('\t')[1]:x.split('\t')[0] for x in remote_end_lines}
assert pr_end['headRefOid']==HEAD and pr_end['state']=='OPEN' and pr_end['isDraft'] is True
assert commit_end['tree']['sha']==TREE and remote_end[f"refs/heads/{pr_end['headRefName']}"]==HEAD and remote_end['refs/pull/418/head']==HEAD

wjsonl(ROWS_OUT,records)
summary={'schemaVersion':1,'repository':'snapetech-org/SeerrNG','pullRequest':418,'prState':pr_end['state'],'isDraft':pr_end['isDraft'],
'exactHead':HEAD,'exactTree':TREE,'sourcePositions':[3000,3049],'sourceCount':50,'localeCount':12,'cellCount':600,
'primaryProposalRowsInSlice':sum(1 for x in primary_proposals if 3000<=x['sourcePosition']<=3049),
'primaryProposalFileSha256':PROPOSALS_SHA,'primaryProposalReviewCounts':dict(proposal_reviews),
'independentVerdictCounts':dict(counts),'holds':12,
'heldSourceIds':['components.RequestModal.QuotaDisplay.magazinelimit'],'heldLocales':LOCALES,
'resolvedRequestTreeExtractorAliases':8,'callerContextsReviewed':50,'callerLinePinsIncluded':sum(len(x['callerPins']) for x in records),
'inputBundleSha256':SUMS_SHA,'resolvedCellsSha256':CELLS_SHA,'resolvedCallerContextsSha256':CALLERS_SHA,
'callerGapTriageSha256':TRIAGE_SHA,'headReattestationSha256':HEAD_REPORT_SHA,
'catalogsByteIdenticalToOldPin':True,'currentCellMismatchesAtExactHead':0,
'inputReportedPlaceholderMismatchCells':sum(x['placeholderParity']!='exact' for x in slice_rows),
'inputReportedMarkupMismatchCells':sum(x['markupParity']!='exact' for x in slice_rows),
'independentStructuralFailures':0,'nativeSpeakerReviewOutstanding':True,'nativeSpeakerApproval':False,
'testsBuildScansCiBrowserRun':False,'repositoryOrPrEdited':False,
'confidence':'moderate overall; language-specific candidates are machine-assisted and still need native-speaker review'}
att={'capturedAtUtc':datetime.now(timezone.utc).isoformat(),'repository':'snapetech-org/SeerrNG','pullRequest':418,
'livePrStart':pr,'livePrEnd':pr_end,'exactHead':HEAD,'exactTree':TREE,'remoteRefsAtSeal':remote_end,
'inputBundleSha256':SUMS_SHA,'resolvedCellsSha256':CELLS_SHA,'resolvedCallerContextsSha256':CALLERS_SHA,
'callerGapTriageSha256':TRIAGE_SHA,'headReattestationSha256':HEAD_REPORT_SHA,'inputChecksums':input_checks,
'parentHeadReportReattestsAll12CatalogsAnd21CallerFiles':True,'currentCellMismatchesAtExactHead':0,
'rows':len(records),'sourceIds':50,'locales':12,'callerPinsLinkedToCellAndExactHeadAttestation':True,
'noCallerHoldSourceIds':['components.RequestModal.QuotaDisplay.magazinelimit'],
'requestTreeAliasRepairsUsed':8,'repoOrPrEdited':False,'testsBuildScansCiBrowserRun':False}
wjson(SUMMARY_OUT,summary); wjson(ATTEST_OUT,att)
README_OUT.write_text(
f"""# SeerrNG PR #418 W3000–3049 independent cross-review

Exact live PR head/tree: {HEAD} / {TREE}. The exact-head bundle reattests that the docs-only head movement left all locale catalogs and caller files byte-identical; live PR and remote refs were rechecked at seal.

Scope: 50 source IDs × 12 locales = 600 cells. I independently reviewed 209 primary proposals in this half-window and the other current targets. Proposal dispositions: {proposal_reviews['accept']} accepted, {proposal_reviews['revise']} revised, {proposal_reviews['reject']} rejected. Overall current-cell dispositions: {counts['accept-current']} accept-current, {counts['correction']} corrections, {counts['refinement']} refinements, and 12 holds.

Hold all 12 locales of components.RequestModal.QuotaDisplay.magazinelimit: exact-head search found only its English definition, while the adjacent quota selector routes to seasonlimit without a magazine branch. Confirm/fix the caller before using translations.

The eight RequestTree extractor gaps were resolved to RequestSeasonEpisodeTree.tsx and were reviewed against the hash-pinned resolved contexts. Input-reported structural count mismatches at source 3009 are explained by mutually exclusive ICU plural branches; independent variable-name, selector, brace, and markup checks pass.

Native-speaker approval is not claimed. No repository or PR edits, tests, builds, scans, CI, or browser work occurred.

See subreview-3000-3049.jsonl, subreview-3000-3049-summary.json, and subreview-3000-3049-reattestation.json.
""",encoding='utf-8')
sealed=[]
for f in [ROWS_OUT,SUMMARY_OUT,ATTEST_OUT,README_OUT]:
    sealed.append({'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())})
wjson(MANIFEST_OUT,{'schemaVersion':1,'exactHead':HEAD,'exactTree':TREE,'files':sealed})
SUMS_OUT.write_text(''.join(f'{sha(f.read_bytes())}  {f.name}\n' for f in [ROWS_OUT,SUMMARY_OUT,ATTEST_OUT,README_OUT,MANIFEST_OUT]),encoding='utf-8')
print(json.dumps({'summary':summary,'output':str(ROWS_OUT),'outputSha256':sha(ROWS_OUT.read_bytes()),'checksumFile':str(SUMS_OUT)},ensure_ascii=False,indent=2))
