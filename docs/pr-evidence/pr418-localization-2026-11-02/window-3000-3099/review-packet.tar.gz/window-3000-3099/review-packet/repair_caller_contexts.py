import hashlib,json,pathlib,re,subprocess
OUT=pathlib.Path(__file__).parent
REPO='/home/keith/Documents/code/task-worktrees/localization-20261102-seerrng'
HEAD='9fecce15b52cbcf392a48c48597dd16eddf552b9'
def git(*args): return subprocess.check_output(['git','-C',REPO,*args])
def sha(v): return hashlib.sha256(v if isinstance(v,bytes) else v.encode()).hexdigest()
def canon(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
contexts=[json.loads(s) for s in open(OUT/'caller-contexts.jsonl')]
aliased={
 'components.RequestModal.RequestTree.loadError',
 'components.RequestModal.RequestTree.loadErrorHint',
 'components.RequestModal.RequestTree.loading',
 'components.RequestModal.RequestTree.noSeasons',
 'components.RequestModal.RequestTree.retryTooltip',
 'components.RequestModal.RequestTree.seasonNumber',
 'components.RequestModal.RequestTree.specials',
 'components.RequestModal.RequestTree.untitled',
}
repairs=[]
for c in contexts:
 if c['sourceId'] not in aliased: continue
 path='src/components/RequestModal/RequestSeasonEpisodeTree.tsx'
 raw=git('show',f'{HEAD}:{path}'); lines=raw.decode().splitlines(); leaf=c['sourceId'].split('.')[-1]
 refs=[]
 for i,line in enumerate(lines):
  if re.search(r'\b'+re.escape(leaf)+r'\b',line):
   refs.append({'file':path,'line':i+1,'lineText':line.strip(),'lineSha256':sha(line),'previousLine':lines[i-1].strip() if i else None,'nextLine':lines[i+1].strip() if i+1<len(lines) else None})
 assert len(refs)>=2,(c['sourceId'],refs)
 c['callerPaths']=[path]
 c['callerFiles']=[{'path':path,'blob':git('rev-parse',f'{HEAD}:{path}').decode().strip(),'fileSha256':sha(raw)}]
 c['pinnedLineRefs']=refs
 c['callerUseStatus']='direct-or-helper-reference-found'
 c['callerEvidenceNote']='Extractor alias repaired from source group RequestTree to exact caller RequestSeasonEpisodeTree.tsx after bounded exact-head search. Pinned source definition and message formatMessage callsite; this remains a bounded static search, not a complete dynamic call graph.'
 repairs.append({'sourceId':c['sourceId'],'sourceGroup':'components.RequestModal.RequestTree','repairedCallerPath':path,'callerFileSha256':sha(raw),'callerBlob':git('rev-parse',f'{HEAD}:{path}').decode().strip(),'pinnedLineRefs':refs,'repairReason':'The extraction heuristic looked for a file named RequestTree, while the exact caller file is RequestSeasonEpisodeTree.tsx.'})
with open(OUT/'caller-contexts-resolved.jsonl','w') as f:
 for x in contexts: f.write(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n')
# Record initial extractor gaps and independent exact-head search outcomes for likely orphan keys.
source_rows={x['sourceId']:x for x in json.load(open(OUT/'source-window.json'))['sourceList']}
en_raw=git('show',f'{HEAD}:src/i18n/locale/en.json').decode(); en_lines=en_raw.splitlines(); en_info=json.load(open(OUT/'input-manifest.json'))['sourceCatalog']
triage=[]
for sid in sorted({x['sourceId'] for x in contexts if x['callerUseStatus'] in ('caller-use-not-found','definition-only-or-single-reference')}):
 c=next(x for x in contexts if x['sourceId']==sid)
 if sid in aliased:
  source_line=next((i+1 for i,line in enumerate(en_lines) if json.dumps(sid,ensure_ascii=False)[1:-1] in line),None)
  triage.append({'sourceId':sid,'sourceEnglishLocation':{'file':'src/i18n/locale/en.json','line':source_line,'lineText':en_lines[source_line-1].strip() if source_line else None,'lineSha256':sha(en_lines[source_line-1]) if source_line else None,'catalogBlob':en_info['blob'],'catalogSha256':en_info['sha256'],'sourcePosition':source_rows[sid]['position'],'sourceId':sid,'sourceText':source_rows[sid]['source']},'initialExtractorStatus':'caller-use-not-found','classification':'extractor-alias-limitation-resolved','callerPins':next(x['pinnedLineRefs'] for x in repairs if x['sourceId']==sid),'callerPaths':['src/components/RequestModal/RequestSeasonEpisodeTree.tsx'],'recommendation':'Use the RequestSeasonEpisodeTree.tsx alias for caller-context extraction; no source-string or caller change is needed for this extraction gap.'})
 else:
  source_line=next((i+1 for i,line in enumerate(en_lines) if json.dumps(sid,ensure_ascii=False)[1:-1] in line),None)
  refs=c['pinnedLineRefs']; path=c['callerPaths'][0] if c['callerPaths'] else None
  evidence={'definitionPins':refs,'exactHeadSearch':{'terms':[sid.split('.')[-1],sid], 'filesSearched':'all tracked src/**/*.ts,tsx,js,jsx excluding tests, at the pinned PR tree','result':'Only the defineMessages English source definition was found; no key callsite or dynamic-key alias surfaced in bounded search.'}}
  rec='Hold all 12 locale cells pending caller/source-owner review; do not infer runtime wording. Confirm whether this key is obsolete or should be wired into the UI.'
  if sid.endswith('.QuotaDisplay.magazinelimit'):
   evidence['adjacentCallerEvidence']={'file':'src/components/RequestModal/QuotaDisplay/index.tsx','pins':[{'line':170,'lineSha256':sha('                              : messages.seasonlimit,'),'lineText':'                              : messages.seasonlimit,'}],'observation':'The quota limit chooser routes its default branch to seasonlimit and has no magazine-specific branch; magazinelimit appears only in its definition. This is a likely missed magazine case, but code correction and post-fix caller re-attestation are outside this scratch-only review.'}
   rec='Hold all 12 cells. Ask source owner to confirm the caller bug: magazine quota details appear to use seasonlimit because the mediaType branch has no messages.magazinelimit case. Add or confirm that caller before translating this unused key.'
  elif sid.endswith('.Sportarr.notRequestable'):
   rec='Hold all 12 cells. The source key is defined but no direct or bounded dynamic caller reference was found; confirm whether the key is obsolete or should be wired into a request-disabled state.'
  elif sid.endswith('.autoapproval'):
   rec='Hold all 12 cells. The source key is defined but no direct or bounded dynamic caller reference was found; confirm whether the key is obsolete or should be used as an approval setting label.'
  triage.append({'sourceId':sid,'sourceEnglishLocation':{'file':'src/i18n/locale/en.json','line':source_line,'lineText':en_lines[source_line-1].strip() if source_line else None,'lineSha256':sha(en_lines[source_line-1]) if source_line else None,'catalogBlob':en_info['blob'],'catalogSha256':en_info['sha256'],'sourcePosition':source_rows[sid]['position'],'sourceId':sid,'sourceText':source_rows[sid]['source']},'initialExtractorStatus':'definition-only-or-single-reference','classification':'no-runtime-caller-found-in-bounded-search','callerPaths':c['callerPaths'],'callerPins':refs,'callerGapEvidence':evidence,'recommendation':rec})
with open(OUT/'caller-gap-extraction-triage.json','w') as f: json.dump({'exactHead':HEAD,'sourceIds':len(source_rows),'initialExtractorNoCallerCount':8,'extractorAliasRepairs':len(repairs),'trueNoCallerFoundAfterAliasRepair':3,'aliasRepairs':repairs,'unmappedHoldSources':triage,'confidence':'moderate; bounded static source search, not dynamic call-graph proof'},f,ensure_ascii=False,indent=2)
print(json.dumps({'resolvedContexts':len(contexts),'extractorAliasRepairs':len(repairs),'initialExtractorNoCaller':8,'noCallerFoundAfterAliasRepair':3,'holds':[(x['sourceId'],x['sourceEnglishLocation']['sourcePosition']) for x in triage if x['classification']=='no-runtime-caller-found-in-bounded-search']},ensure_ascii=False,indent=2))
