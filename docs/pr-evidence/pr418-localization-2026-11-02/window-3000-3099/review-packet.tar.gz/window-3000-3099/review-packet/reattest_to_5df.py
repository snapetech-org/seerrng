import collections,hashlib,json,pathlib,re,subprocess
OUT=pathlib.Path(__file__).parent
REPO=pathlib.Path('/home/keith/Documents/code/task-worktrees/localization-20261102-seerrng')
OLD='9fecce15b52cbcf392a48c48597dd16eddf552b9'; HEAD='5df4c711f832f1f9a818c4d9cfca46661bff0835'; TREE='116ff2934d7eaf3d02f84f104621860c16babc01'; REPO_NAME='snapetech-org/SeerrNG'; PR=418
LOCALES=['ar','de','es','fr','hi','id','ja','ko','pt_BR','vi','zh_Hans','zh_Hant']
def run(*a):return subprocess.check_output(a,text=True)
def gitb(*a):return subprocess.check_output(['git','-C',str(REPO),*a])
def quiet(*a):return subprocess.run(['git','-C',str(REPO),*a],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
def sha(x):return hashlib.sha256(x if isinstance(x,bytes) else x.encode()).hexdigest()
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def dump(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
pr=json.loads(run('gh','pr','view',str(PR),'--repo',REPO_NAME,'--json','state,isDraft,headRefOid,headRefName,baseRefOid,url'))
remote=run('git','ls-remote','https://github.com/snapetech-org/SeerrNG.git',f'refs/heads/{pr["headRefName"]}').split()[0]
local=run('git','-C',str(REPO),'rev-parse','HEAD').strip(); tree=run('git','-C',str(REPO),'rev-parse','HEAD^{tree}').strip()
assert pr['state']=='OPEN' and pr['isDraft'] and pr['headRefOid']==HEAD and remote==HEAD and local==HEAD and tree==TREE,(pr,remote,local,tree)
old_manifest=json.load(open(OUT/'input-manifest.json'))
assert old_manifest['head']==OLD
# Verify catalogs and all 1,200 source/current target cells against new exact commit.
source_path='src/i18n/locale/en.json'; source_raw=gitb('show',f'{HEAD}:{source_path}'); source=json.loads(source_raw); source_blob=run('git','-C',str(REPO),'rev-parse',f'{HEAD}:{source_path}').strip()
def flatten(d,p=''):
 for k,v in d.items():
  q=f'{p}.{k}' if p else k
  if isinstance(v,dict):yield from flatten(v,q)
  else:yield q,v
ordered=list(flatten(source)); all_source=dict(ordered)
locale_raw={}; locale_json={}; locale_infos={}
for loc in LOCALES:
 path=f'src/i18n/locale/{loc}.json'; raw=gitb('show',f'{HEAD}:{path}'); obj=json.loads(raw)
 locale_raw[loc]=raw;locale_json[loc]=obj
 locale_infos[loc]={'path':path,'blob':run('git','-C',str(REPO),'rev-parse',f'{HEAD}:{path}').strip(),'sha256':sha(raw),'bytes':len(raw),'keyCount':len(obj)}
cells=[json.loads(x) for x in open(OUT/'source-current-cells.jsonl')]
assert len(cells)==1200
cell_mismatches=[]
for c in cells:
 if all_source.get(c['sourceId'])!=c['source'] or sha(c['source'])!=c['sourceTextSha256'] or locale_json[c['locale']].get(c['sourceId'])!=c['currentTarget'] or sha(c['currentTarget'])!=c['currentTargetHash']:
  cell_mismatches.append({'position':c['sourcePosition'],'sourceId':c['sourceId'],'locale':c['locale']})
assert not cell_mismatches,cell_mismatches
# Rehash every resolved caller file and pinned line at current exact head.
contexts=[json.loads(x) for x in open(OUT/'caller-contexts-resolved.jsonl')]
assert len(contexts)==100
caller_file_checks={}; caller_line_checks=0; caller_gaps=[]
for c in contexts:
 if c['callerUseStatus']=='caller-use-not-found':caller_gaps.append(c['sourceId'])
 for f in c['callerFiles']:
  raw=gitb('show',f'{HEAD}:{f["path"]}'); b=run('git','-C',str(REPO),'rev-parse',f'{HEAD}:{f["path"]}').strip()
  info={'path':f['path'],'recordedBlob':f['blob'],'currentBlob':b,'recordedSha256':f['fileSha256'],'currentSha256':sha(raw),'same':b==f['blob'] and sha(raw)==f['fileSha256']}
  caller_file_checks[f['path']]=info
  assert info['same'],info
  lines=raw.decode().splitlines()
  for ref in c['pinnedLineRefs']:
   if ref['file']!=f['path']:continue
   line=lines[ref['line']-1]; caller_line_checks+=1
   assert sha(line)==ref['lineSha256'] and line.strip()==ref['lineText'],(c['sourceId'],ref)
assert not caller_gaps,caller_gaps
# Verify all boundary readbacks and prior W2999 final targets at current catalogs.
boundaries=[json.loads(x) for x in open(OUT/'window-boundary-all-12-readbacks.jsonl')]
assert len(boundaries)==48
for r in boundaries:
 assert source.get(r['sourceId'])==r['source']
 assert locale_json[r['locale']].get(r['sourceId'])==r['currentTarget'] and sha(r['currentTarget'])==r['currentTargetHash']
 r['exactHead']=HEAD;r['exactTree']=TREE
assert sum(r['position']==2999 and r['priorBoundaryDispositionMatchesCurrent'] is True for r in boundaries)==12
(OUT/'window-boundary-all-12-readbacks.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n' for x in boundaries))
# Update the exact-head framing while preserving the earlier frozen content rows.
sw=json.load(open(OUT/'source-window.json')); sw['head']=HEAD;sw['tree']=TREE; dump(OUT/'source-window.json',sw)
source_bounds=json.load(open(OUT/'source-boundaries.json')); source_bounds['exactHead']=HEAD;source_bounds['exactTree']=TREE;source_bounds['sourceCatalogBlob']=source_blob;source_bounds['sourceCatalogSha256']=sha(source_raw);dump(OUT/'source-boundaries.json',source_bounds)
pb=json.load(open(OUT/'prior-disposition-boundary.json'));pb['exactHead']=HEAD;pb['exactTree']=TREE;pb['sourceCatalogBlob']=source_blob;pb['sourceCatalogSha256']=sha(source_raw);dump(OUT/'prior-disposition-boundary.json',pb)
tri=json.load(open(OUT/'caller-gap-extraction-triage.json'));tri['exactHead']=HEAD;tri['exactTree']=TREE;tri['callerReattestedAtHead']=HEAD;dump(OUT/'caller-gap-extraction-triage.json',tri)
# Bind each manual proposal to the new exact head and verify its source/current hashes.
props=[json.loads(x) for x in open(OUT/'manual-proposals.jsonl')]
for p in props:
 p['exactHead']=HEAD;p['exactTree']=TREE
 c=next(x for x in cells if x['sourcePosition']==p['position'] and x['locale']==p['locale'])
 assert p['sourceId']==c['sourceId'] and p['currentTargetHash']==c['currentTargetHash'] and p['sourceTextSha256']==c['sourceTextSha256']
(OUT/'manual-proposals.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n' for x in props))
# Fresh PR start state, exact code tree, and tracked-worktree status are recorded separately from old start snapshot.
status=run('git','-C',str(REPO),'status','--porcelain=v1','--untracked-files=all').splitlines()
start={'repository':REPO_NAME,'pullRequest':PR,'url':pr['url'],'state':pr['state'],'isDraft':pr['isDraft'],'headRefName':pr['headRefName'],'head':HEAD,'tree':TREE,'baseRefOid':pr['baseRefOid'],'remoteBranchHead':remote,'localHead':local,'localTree':tree,'worktree':str(REPO),'worktreeStatus':status,'trackedWorktreeDiffClean':quiet('diff','--quiet') and quiet('diff','--cached','--quiet'),'note':'The modified AGENTS.md and .next-webpack-dev symlink were present in the shared worktree and were not changed by this task; all review inputs are read from the exact commit object.'}
dump(OUT/'pr-snapshot-reattestation.json',start)
# Compare all paths between old and new commit.
changed=run('git','-C',str(REPO),'diff','--name-status',OLD,HEAD).splitlines()
assert all(line.startswith('A\tdocs/pr-evidence/pr418-localization-2026-11-02/agentvm-browser-review-final-9fecce15/') for line in changed),changed
head_att={'repository':REPO_NAME,'pullRequest':PR,'exactHead':HEAD,'exactTree':TREE,'previousPinnedHead':OLD,'livePullRequest':pr,'remoteBranchHead':remote,'localHead':local,'localTree':tree,'commitDiffFiles':changed,'commitDiffClassification':'Only browser-review evidence files added under docs/pr-evidence/.../agentvm-browser-review-final-9fecce15; no source, locale catalog, or caller source changed.','sourceCatalog':{'path':source_path,'blob':source_blob,'sha256':sha(source_raw),'matchesOldPin':source_blob==old_manifest['sourceCatalog']['blob'] and sha(source_raw)==old_manifest['sourceCatalog']['sha256']},'localeCatalogs':locale_infos,'all12CatalogsMatchOldPin':all(locale_infos[l]['blob']==old_manifest['localeCatalogs'][l]['blob'] and locale_infos[l]['sha256']==old_manifest['localeCatalogs'][l]['sha256'] for l in LOCALES),'cellsChecked':len(cells),'sourceCurrentCellMismatches':len(cell_mismatches),'callerContextRows':len(contexts),'callerFilesChecked':len(caller_file_checks),'callerLinesChecked':caller_line_checks,'callerFileChecks':list(caller_file_checks.values()),'unresolvedNoCallerSourceIds':caller_gaps,'previousW2999FinalTargetsMatchingCurrent':sum(r['position']==2999 and r['priorBoundaryDispositionMatchesCurrent'] is True for r in boundaries),'all48BoundaryReadbacksReattested':len(boundaries),'worktreeStatus':status,'reattestation':'All English/locale current values, resolved caller file blobs, and pinned caller lines were rehashed at the new exact PR head. The code/catalog/caller content hashes match the previous pin.'}
dump(OUT/'head-reattestation.json',head_att)
manifest=json.load(open(OUT/'input-manifest.json'));manifest.update({'head':HEAD,'tree':TREE,'livePullRequest':pr,'remoteBranchHead':remote,'localeCatalogs':locale_infos,'sourceCatalog':{'path':source_path,'blob':source_blob,'sha256':sha(source_raw),'bytes':len(source_raw)},'resolvedCallerContextRows':len(contexts),'resolvedCallerFiles':len(caller_file_checks),'resolvedCallerReferences':caller_line_checks,'headReattestationPath':'head-reattestation.json','worktreeClean':not status,'trackedWorktreeDiffClean':start['trackedWorktreeDiffClean'],'worktreeStatus':status,'previousPin':OLD,'previousPinContentUnchanged':True})
dump(OUT/'input-manifest.json',manifest)
# Add exact pin to all hold rows.
holds=[json.loads(x) for x in open(OUT/'caller-context-holds.jsonl')]
for h in holds: h['exactHead']=HEAD;h['exactTree']=TREE
(OUT/'caller-context-holds.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n' for x in holds))
# Rebuild input checksum manifest; include resolved caller map and explicit holds/triage.
input_names=['source-window.json','source-current-cells.jsonl','caller-contexts.jsonl','caller-contexts-resolved.jsonl','caller-gap-extraction-triage.json','caller-context-holds.jsonl','prior-disposition-boundary.json','input-manifest.json','source-boundaries.json']
(OUT/'INPUT-SHA256SUMS').write_text(''.join(f'{sha((OUT/n).read_bytes())}  {n}\n' for n in input_names))
# Ensure state remained exact through the reattestation write.
pr2=json.loads(run('gh','pr','view',str(PR),'--repo',REPO_NAME,'--json','state,isDraft,headRefOid,headRefName,baseRefOid,url'));remote2=run('git','ls-remote','https://github.com/snapetech-org/SeerrNG.git',f'refs/heads/{pr2["headRefName"]}').split()[0]
assert pr2['headRefOid']==HEAD and remote2==HEAD and run('git','-C',str(REPO),'rev-parse','HEAD^{tree}').strip()==TREE
print(json.dumps({'head':HEAD,'tree':TREE,'headAttestationSha256':sha((OUT/'head-reattestation.json').read_bytes()),'inputSumsSha256':sha((OUT/'INPUT-SHA256SUMS').read_bytes()),'all12CatalogsMatch':head_att['all12CatalogsMatchOldPin'],'cellsReattested':len(cells),'callerFilesChecked':len(caller_file_checks),'callerLinesChecked':caller_line_checks,'previousW2999Matches':head_att['previousW2999FinalTargetsMatchingCurrent'],'holds':len(holds),'manualProposals':len(props),'inputManifestSha256':sha((OUT/'input-manifest.json').read_bytes()),'worktreeStatus':status},ensure_ascii=False,indent=2))
