import collections, datetime, hashlib, json, pathlib, re, subprocess
OUT = pathlib.Path(__file__).parent
REPO = pathlib.Path('/home/keith/Documents/code/task-worktrees/localization-20261102-seerrng')
HEAD = '5df4c711f832f1f9a818c4d9cfca46661bff0835'
TREE = '116ff2934d7eaf3d02f84f104621860c16babc01'
LOCS = ['ar','de','es','fr','hi','id','ja','ko','pt_BR','vi','zh_Hans','zh_Hant']
REQUIRED = {'ar':{'zero','one','two','few','many','other'},'de':{'one','other'},'es':{'one','many','other'},'fr':{'one','many','other'},'hi':{'one','other'},'id':{'other'},'ja':{'other'},'ko':{'other'},'pt_BR':{'one','many','other'},'vi':{'other'},'zh_Hans':{'other'},'zh_Hant':{'other'}}
TERMS = ['SeerrNG','Seerr','Jellyfin','Plex','Tautulli','Jellystat','TMDB','TheTVDB.com','TheTVDB','Whisparr','ISBN','TVmaze','Wikidata','CC0','CC BY-SA 4.0','HTTP','HTTPS','URL','HD','4K','FLAC','MP3','Lidarr','LazyLibrarian','Spotify','YouTube','MusicBrainz','Discogs','Metacritic','Trakt','ROM','PC','ROMarrNG','Radarr','Sonarr','Bookshelf','Open Library','Bindery','BackIssue','Sportarr']
def sha(v): return hashlib.sha256(v if isinstance(v,bytes) else v.encode()).hexdigest()
def canon(v): return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def readj(n): return json.loads((OUT/n).read_text())
def readjl(n): return [json.loads(x) for x in (OUT/n).read_text().splitlines() if x.strip()]
def writej(n,v): (OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
def writejl(n,rows): (OUT/n).write_text(''.join(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n' for x in rows))
def tags(s): return re.findall(r'</?[A-Za-z][^>]*>',s)
def hasterm(text,term):
    if term in ('ROM','PC','4K','HD'):
        suffix='s?' if term=='ROM' else ''
        return re.search(r'(?<![A-Za-z0-9])'+re.escape(term)+suffix+r'(?![A-Za-z0-9])',text) is not None
    return term.casefold() in text.casefold()
def matchbrace(s,start):
    depth=1; i=start+1
    while i<len(s) and depth:
        if s[i]=='{': depth+=1
        elif s[i]=='}': depth-=1
        i+=1
    if depth: raise ValueError('unclosed brace')
    return i

def parse_sequence(s):
    out=[]; text=[]; i=0
    def flush():
        if text:
            out.append(('text',''.join(text))); text.clear()
    while i<len(s):
        if s[i]!='{':
            if s[i]=='}': raise ValueError('unmatched closing brace')
            text.append(s[i]); i+=1; continue
        flush(); end=matchbrace(s,i); inner=s[i+1:end-1]
        root=re.match(r'\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*(plural|select|selectordinal)\s*,',inner)
        if not root:
            arg=re.match(r'\s*([A-Za-z_][A-Za-z0-9_]*)',inner)
            if not arg: raise ValueError('unrecognized placeholder '+inner[:80])
            out.append(('arg',arg.group(1))); i=end; continue
        name,kind=root.group(1),root.group(2); j=root.end(); branches=[]
        while j<len(inner):
            while j<len(inner) and inner[j].isspace(): j+=1
            if j>=len(inner): break
            sm=re.match(r'(?:=?\d+|[A-Za-z][A-Za-z0-9_-]*)',inner[j:])
            if not sm: raise ValueError('bad ICU selector '+inner[j:j+80])
            selector=sm.group(0); j+=len(selector)
            while j<len(inner) and inner[j].isspace(): j+=1
            if j>=len(inner) or inner[j]!='{': raise ValueError('missing ICU branch body')
            bend=matchbrace(inner,j); body=inner[j+1:bend-1]
            branches.append((selector,parse_sequence(body))); j=bend
        if not branches: raise ValueError('ICU has no branches')
        out.append(('icu',name,kind,branches)); i=end
    flush(); return out

def eval_paths(nodes):
    paths=[(collections.Counter(),'',0)]
    for node in nodes:
        variants=[]
        if node[0]=='text':
            variants=[(collections.Counter(),node[1],node[1].count('#'))]
        elif node[0]=='arg':
            variants=[(collections.Counter({node[1]:1}),'',0)]
        else:
            _,name,kind,branches=node
            for selector,body in branches:
                for counts,rendered,pounds in eval_paths(body):
                    c=counts.copy(); c[name]+=1
                    variants.append((c,rendered,pounds))
        new=[]
        for c0,t0,p0 in paths:
            for c1,t1,p1 in variants:
                c=c0.copy(); c.update(c1)
                new.append((c,t0+t1,p0+p1))
        paths=new
    return paths

def top_icu(nodes):
    out=[]
    for n in nodes:
        if n[0]=='icu':
            out.append({'name':n[1],'kind':n[2],'selectors':[x[0] for x in n[3]]})
    return out

def path_profiles(nodes):
    out=[]
    for counts,rendered,pounds in eval_paths(nodes):
        out.append({'vars':dict(sorted(counts.items())),'markup':tags(rendered),'poundCount':pounds})
    return out

def profile_set(profiles,key):
    return {json.dumps(p[key],ensure_ascii=False,sort_keys=True,separators=(',',':')) for p in profiles}
def result_profiles(s): return path_profiles(parse_sequence(s))

# Reattest exact repo, official remote, and PR before sealing any result.
local_head=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
local_tree=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD^{tree}'],text=True).strip()
branch='codex/seerrng-localization-overhaul-20261028'
remote_head=subprocess.check_output(['git','-C',str(REPO),'ls-remote','github','refs/heads/'+branch],text=True).split()[0]
pr=json.loads(subprocess.check_output(['gh','pr','view','418','--repo','snapetech-org/SeerrNG','--json','headRefOid,headRefName,headRepository,state,isDraft,updatedAt'],text=True))
assert (local_head,local_tree,remote_head,pr['headRefOid'])==(HEAD,TREE,HEAD,HEAD), (local_head,local_tree,remote_head,pr)
assert pr['state']=='OPEN' and pr['headRefName']==branch and pr['headRepository']['nameWithOwner'].lower()=='snapetech-org/seerrng'
writej('live-exact-head-reattestation.json',{'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'localHead':local_head,'localTree':local_tree,'githubRemoteBranch':branch,'githubRemoteHead':remote_head,'prHead':pr['headRefOid'],'prState':pr['state'],'prIsDraft':pr['isDraft'],'prUpdatedAt':pr['updatedAt'],'officialRemote':'github','verifiedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')})

# Verify sealed input checksums and common source/caller pin set.
for line in (OUT/'INPUT-SHA256SUMS').read_text().splitlines():
    expected,name=line.split('  ',1); assert sha((OUT/name).read_bytes())==expected,(name,expected)
for name,expected in [('subreview-3000-3049.jsonl','352f549af6b218840e5b431534722c7b5f5abf2101b510d6acbb5e3dc1b668b6'),('subreview-3050-3099.jsonl','87f35768178255092f1156a7f2dff55713b3436546b9a7f54e7f8f90374167e4'),('independent-suggestions-3000-3049.jsonl','ba69b926326359e523ac639842ef9ed601aaff4ff67ccabfd76918823f8e4a1f'),('independent-suggestions-3050-3099.jsonl','c7c4bd98ea90baa59713935f755aa18e68dcdf80330519e34c5060223d772218'),('manual-proposals-at-crossreview.jsonl','f11e4d1dbd2e41132b0ce931203c47069b6ce6e8a18e38747554f8ea9860af68')]:
    assert sha((OUT/name).read_bytes())==expected,(name,sha((OUT/name).read_bytes()))

cells=readjl('source-current-cells-resolved.jsonl'); assert len(cells)==1200
cellmap={(x['sourcePosition'],x['locale']):x for x in cells}; assert len(cellmap)==1200
contexts={x['sourceId']:x for x in readjl('caller-contexts-resolved.jsonl')}; assert len(contexts)==100
base=readjl('manual-proposals-at-crossreview.jsonl'); baseprops={(x['position'],x['locale']):x for x in base}; assert len(base)==320
holds={(x['sourcePosition'],x['locale']):x for x in readjl('caller-context-holds.jsonl')}; assert len(holds)==36
sub1=readjl('subreview-3000-3049.jsonl'); sub2=readjl('subreview-3050-3099.jsonl'); assert len(sub1)==len(sub2)==600
suggest1=readjl('independent-suggestions-3000-3049.jsonl'); suggest2=readjl('independent-suggestions-3050-3099.jsonl'); suggestions=suggest1+suggest2; assert len(suggestions)==66
reviews={}
for r in sub1+sub2:
    k=(r['sourcePosition'],r['locale']); assert k not in reviews; reviews[k]=r
assert len(reviews)==1200

# Reconcile every independent row to the exact source/current/caller cell.
reconciliation=[]; cross_counts=collections.Counter(); primary_compare=collections.Counter(); review_errors=[]
for k,c in sorted(cellmap.items()):
    r=reviews[k]; pos,loc=k
    assert r['exactHead']==HEAD and r['exactTree']==TREE and r['sourceId']==c['sourceId'] and r['currentTarget']==c['currentTarget'] and r['currentTargetHash']==c['currentTargetHash'],(k,'source/current/head mismatch')
    if 'independentVerdict' in r:
        verdict=r['independentVerdict']; source=r['source']; source_sha=r['sourceTextSha256']
        assert source==c['source'] and source_sha==c['sourceTextSha256'] and r['callerContextRef']==c['callerContextRef'] and r['callerContextSha256']==c['callerContextSha256'],(k,'first-half source/caller mismatch')
        assert r['catalogFileSha256']==c['localeFileSha256'] and r['catalogGitBlob']==c['localeBlob'] and r['sourceLocation']['fileSha256']==c['sourceFileSha256'] and r['sourceLocation']['gitBlob']==c['sourceCatalogBlob'],(k,'catalog/source-file pin mismatch')
        checks=r['placeholderMarkupIcuProtectedLiteralChecks']; assert checks.get('allRequiredChecksPass') is True,(k,'first-half structural review failed')
        assert r.get('nativeSpeakerApproval') is False
        comp=r.get('primaryProposalReview') or {}; compout=comp.get('disposition','none')
        artifact=r.get('callerContextArtifact',{}); assert artifact.get('sha256')==sha((OUT/'caller-contexts-resolved.jsonl').read_bytes())
        if r.get('candidateTarget') is not None: assert sha(r['candidateTarget'])==r['candidateTargetSha256']
    else:
        verdict=r['verdict']; source=r['sourceText']; source_sha=r['sourceTextSha256']
        assert source==c['source'] and source_sha==c['sourceTextSha256'] and r['sourceHash']==c['sourceHash'] and r['callerContextRef']==c['callerContextRef'] and r['callerContextSha256']==c['callerContextSha256'],(k,'second-half source/caller mismatch')
        assert r['callerPaths']==c['callerPaths'] and set(r['callerPinnedLineHashes']).issubset(set(c['callerPinnedLineHashes'])),(k,'second-half caller line pin mismatch')
        checks=r['structureChecks']; assert checks.get('reviewedPlaceholderParity') is True and checks.get('reviewedMarkupParity') is True,(k,'second-half structural review failed')
        assert r.get('nativeSpeakerApproval') is False
        comp=r.get('primaryProposalComparison') or {}; compout={'agree-primary-proposal':'accept','revise-primary-proposal':'revise'}.get(comp.get('outcome'),'none')
        if r.get('proposedTarget') is not None: assert sha(r['proposedTarget'])==r['proposedTargetSha256']
    assert verdict in ('accept-current','correction','refinement','hold'),(k,verdict)
    cross_counts[verdict]+=1; primary_compare[compout]+=1
    if k in holds: assert verdict=='hold',(k,'hold inventory disagreement')
    if verdict=='hold': assert k in holds,(k,'new hold not in pinned primary hold inventory')
    reconciliation.append({'schemaVersion':1,'exactHead':HEAD,'exactTree':TREE,'pullRequest':418,'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'source':c['source'],'sourceTextSha256':c['sourceTextSha256'],'sourceFile':c['sourceFile'],'sourceFileSha256':c['sourceFileSha256'],'sourceCatalogBlob':c['sourceCatalogBlob'],'localeFile':c['localeFile'],'localeFileSha256':c['localeFileSha256'],'localeBlob':c['localeBlob'],'currentTarget':c['currentTarget'],'currentTargetHash':c['currentTargetHash'],'callerContextRef':c['callerContextRef'],'callerContextSha256':c['callerContextSha256'],'callerContextSha256Original':c['callerContextSha256Original'],'callerPaths':r.get('callerPaths',c['callerPaths']),'callerLineHashes':r.get('callerPinnedLineHashes',[x.get('lineSha256') for x in r.get('callerPins',[])]) or c['callerPinnedLineHashes'],'independentReviewer':r.get('reviewer'),'independentVerdict':verdict,'independentRationale':r.get('rationale'),'independentConfidence':r.get('confidence'),'primaryCandidatePresent':k in baseprops,'primaryReviewDisposition':compout,'reviewerCandidate':r.get('candidateTarget',r.get('proposedTarget')),'reviewerCandidateHash':r.get('candidateTargetSha256',r.get('proposedTargetSha256')),'nativeSpeakerApproval':False,'structuralReview':checks,'holdEvidence':r.get('holdEvidence',r.get('holdRationale'))})
assert cross_counts==collections.Counter({'accept-current':781,'correction':271,'refinement':112,'hold':36}),cross_counts
assert len(reconciliation)==1200 and len(holds)==36

# Merge cross-review additions and revise three existing proposals without altering the pinned original input.
finalprops={k:dict(v) for k,v in baseprops.items()}
added=[]; revised=[]
for s in suggestions:
    pos=s['sourcePosition']; loc=s['locale']; k=(pos,loc); c=cellmap[k]
    target=s['target']; review_row=reviews[k]
    target_hash=review_row.get('candidateTargetSha256',review_row.get('proposedTargetSha256'))
    assert sha(target)==target_hash,(k,'suggestion target hash mismatch')
    if k in baseprops:
        p=finalprops[k]
        if target!=p['target']:
            if s.get('reviewOutcome')!='revise-primary-proposal' and s.get('primaryTarget') is None:
                raise AssertionError((k,'unexpected overwrite of a primary proposal'))
            old=p['target']; p['primaryTargetBeforeCrossReview']=old; p['primaryTargetBeforeCrossReviewHash']=p['targetHash']
            p['target']=target; p['targetHash']=sha(target); p['crossReviewDisposition']='revised-primary-proposal'; p['crossReviewRationale']=s.get('rationale','')
            p['independentReviewer']='independent-machine-assisted-semantic-cross-review'; p['independentConfidence']=s.get('confidence','moderate')
            revised.append({'sourcePosition':pos,'locale':loc,'oldTarget':old,'oldTargetHash':sha(old),'finalTarget':target,'finalTargetHash':sha(target),'rationale':s.get('rationale')})
        else:
            assert target==p['target'],(k,'proposal comparison unexpectedly differs')
    else:
        assert k not in holds,(k,'proposal added to held cell')
        cell=c; add={'exactHead':HEAD,'exactTree':TREE,'sourceId':cell['sourceId'],'position':pos,'sourcePosition':pos,'locale':loc,'source':cell['source'],'sourceTextSha256':cell['sourceTextSha256'],'currentTarget':cell['currentTarget'],'currentTargetHash':cell['currentTargetHash'],'target':target,'targetHash':sha(target),'kind':s.get('reviewerDisposition',s.get('verdict')),'rationale':s.get('rationale'),'confidence':s.get('confidence','moderate'),'callerContextRef':cell['callerContextRef'],'callerContextSha256':cell['callerContextSha256'],'callerLineHashes':cell['callerPinnedLineHashes'],'callerPaths':cell['callerPaths'],'callerUseStatus':cell['callerUseStatus'],'sourceFile':cell['sourceFile'],'sourceFileSha256':cell['sourceFileSha256'],'localeFile':cell['localeFile'],'localeFileSha256':cell['localeFileSha256'],'reviewer':'independent-machine-assisted-semantic-cross-review','crossReviewAdded':True}
        finalprops[k]=add; added.append({'sourcePosition':pos,'locale':loc,'kind':add['kind'],'target':target,'targetHash':sha(target),'rationale':add['rationale']})
# Explicit complete ICU category for German W3009; reviewer proposal otherwise omitted required `one` on its first numeric plural.
k=(3009,'de'); assert k in finalprops
old_de=finalprops[k]['target']; new_de='{remaining, plural, =0 {Keine} one {<strong>#</strong>} other {<strong>#</strong>}} {remaining, plural, one {Anfrage für {type} verbleibt} other {Anfragen für {type} verbleiben}}'
finalprops[k]['target']=new_de; finalprops[k]['targetHash']=sha(new_de); finalprops[k]['branchAwareCorrection']='Added the required German one selector to the first remaining-count plural while preserving source exact =0 and other selectors.'
k=(3009,'hi'); assert k in finalprops
old_hi=finalprops[k]['target']; new_hi='{remaining, plural, =0 {कोई} one {<strong>#</strong>} other {<strong>#</strong>}} {type} अनुरोध {remaining, plural, =0 {शेष नहीं है} one {शेष है} other {शेष हैं}}'
finalprops[k]['target']=new_hi; finalprops[k]['targetHash']=sha(new_hi); finalprops[k]['branchAwareCorrection']='Added the required Hindi one selector to the first remaining-count plural while preserving source exact =0 and other selectors.'
assert len(added)==63 and len(revised)==3 and len(finalprops)==383,(len(added),len(revised),len(finalprops))
assert sha((OUT/'manual-proposals-at-crossreview.jsonl').read_bytes())=='f11e4d1dbd2e41132b0ce931203c47069b6ce6e8a18e38747554f8ea9860af68'
writejl('manual-proposals-merged.jsonl',[finalprops[k] for k in sorted(finalprops)])
writejl('crossreview-reconciliation.jsonl',reconciliation)
writej('crossreview-summary.json',{'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'cellCount':1200,'independentReviewRows':1200,'reviewers':['independent-machine-assisted-semantic-cross-review (positions 3000–3049)','independent-machine-assisted-semantic-cross-review (positions 3050–3099)'],'dispositions':dict(cross_counts),'primaryProposalComparisons':dict(primary_compare),'initialPrimaryProposals':len(baseprops),'independentAdditionalFindings':len(added),'primaryProposalRevisions':len(revised),'finalCandidateCount':len(finalprops),'holds':len(holds),'nativeSpeakerApprovalClaimed':False,'subreviewHashes':{'3000-3049':sha((OUT/'subreview-3000-3049.jsonl').read_bytes()),'3050-3099':sha((OUT/'subreview-3050-3099.jsonl').read_bytes())},'suggestionHashes':{'3000-3049':sha((OUT/'independent-suggestions-3000-3049.jsonl').read_bytes()),'3050-3099':sha((OUT/'independent-suggestions-3050-3099.jsonl').read_bytes())}})

# Record the exact W3001 production path and source correction recommendation; catalog cells remain held.
def file_evidence(rel,lines):
    path=REPO/rel; data=path.read_bytes(); rawlines=data.splitlines(keepends=True)
    return {'path':rel,'gitBlob':subprocess.check_output(['git','-C',str(REPO),'hash-object',rel],text=True).strip(),'fileSha256':sha(data),'lines':[{'line':n,'text':rawlines[n-1].decode().rstrip('\r\n'),'lineSha256':sha(rawlines[n-1].rstrip(b'\r\n'))} for n in lines]}
source_fix={'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'sourceId':'components.RequestModal.QuotaDisplay.magazinelimit','sourcePosition':3001,'localeCellsHeld':LOCS,'holdReason':'The key is currently an unused message definition, so its future runtime context remains tied to a source fix not present in this exact head.','definition':file_evidence('src/components/RequestModal/QuotaDisplay/index.tsx',[17]),'productionCaller':file_evidence('src/components/RequestModal/MagazineRequestModal.tsx',[239]),'quotaFormatter':file_evidence('src/components/RequestModal/QuotaDisplay/index.tsx',[157,158,169,170]),'sourceSearch':'Exact source-tree search for magazinelimit/messages.magazinelimit outside locale JSON returns only the definition at QuotaDisplay/index.tsx:17; no production reference to messages.magazinelimit exists.','userVisibleFinding':'MagazineRequestModal passes mediaType="magazine" to QuotaDisplay. When the quota details are rendered, the mediaType selection has no magazine branch and falls through to messages.seasonlimit, so magazine quota text is displayed as seasons. This is a production caller bug; the magazinelimit definition itself is unused at this head.','recommendation':'Add an explicit magazine case in QuotaDisplay’s limit-message selection that uses messages.magazinelimit; then reattest the source and caller pins and review the 12 target cells in that corrected runtime context.','exactMessageKeyCallerVerified':False,'componentCallerVerified':True,'keepAll12CellsHeld':True}
writej('source-fix-recommendation-W3001.json',source_fix)

# Rebuild exact final targets, branch-aware placeholder/markup checks, ICU profiles, protected literals, and apply list.
props=finalprops; ledger=[]; target_rows=[]; candidate_rows=[]; icu_rows=[]; markup_rows=[]; placeholder_rows=[]; protected_rows=[]; apply_rows=[]; structural_errors=[]; icu_invalid=[]; protected_missing=[]; markup_path_mismatch=[]; placeholder_path_mismatch=[]; pound_path_mismatch=[]; pound_rows=[]
for k,c in sorted(cellmap.items()):
    pos,loc=k; p=props.get(k); hold=holds.get(k); target=p['target'] if p else c['currentTarget']; verdict=reviews[k].get('independentVerdict',reviews[k].get('verdict'))
    disposition='hold' if hold else ('propose-correction' if p and p['kind']=='correction' else 'refinement' if p else 'accept-current')
    try:
        src_nodes=parse_sequence(c['source']); cur_nodes=parse_sequence(c['currentTarget']); fin_nodes=parse_sequence(target)
        src_paths=result_profiles(c['source']); fin_paths=result_profiles(target)
    except Exception as e:
        structural_errors.append({'position':pos,'locale':loc,'error':str(e)}); continue
    src_vars=profile_set(src_paths,'vars'); fin_vars=profile_set(fin_paths,'vars')
    if src_vars!=fin_vars: placeholder_path_mismatch.append({'position':pos,'sourceId':c['sourceId'],'locale':loc,'sourcePathProfiles':sorted(src_vars),'finalPathProfiles':sorted(fin_vars)})
    src_markup=profile_set(src_paths,'markup'); fin_markup=profile_set(fin_paths,'markup')
    src_pounds=profile_set(src_paths,'poundCount'); fin_pounds=profile_set(fin_paths,'poundCount')
    if src_pounds!=fin_pounds: pound_path_mismatch.append({'position':pos,'sourceId':c['sourceId'],'locale':loc,'sourcePoundCounts':sorted(src_pounds),'finalPoundCounts':sorted(fin_pounds)})
    pound_rows.append({'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'sourceTextSha256':c['sourceTextSha256'],'finalTargetHash':sha(target),'sourceRenderedPoundCounts':sorted(src_pounds),'finalRenderedPoundCounts':sorted(fin_pounds),'valid':src_pounds==fin_pounds})
    if src_markup!=fin_markup: markup_path_mismatch.append({'position':pos,'sourceId':c['sourceId'],'locale':loc,'sourceMarkupPaths':sorted(src_markup),'finalMarkupPaths':sorted(fin_markup)})
    src_icu=top_icu(src_nodes); fin_icu=top_icu(fin_nodes); valid=True; failure=[]
    if len(src_icu)!=len(fin_icu): valid=False; failure.append('top-level ICU root count differs')
    else:
        for ix,(si,fi) in enumerate(zip(src_icu,fin_icu)):
            if (si['name'],si['kind'])!=(fi['name'],fi['kind']): valid=False; failure.append('ICU root/type differs at index '+str(ix)); continue
            src_exact={x for x in si['selectors'] if x.startswith('=')}; missing_exact=src_exact-set(fi['selectors'])
            if missing_exact: valid=False; failure.append('missing exact selectors '+','.join(sorted(missing_exact)))
            required=REQUIRED[loc] if si['kind']=='plural' else set()
            missing_required=required-set(fi['selectors'])
            if missing_required: valid=False; failure.append('missing required locale selectors '+','.join(sorted(missing_required)))
            if si['kind']!='plural' and not set(si['selectors']).issubset(set(fi['selectors'])): valid=False; failure.append('source selector missing')
    if not valid:
        icu_invalid.append({'position':pos,'sourceId':c['sourceId'],'locale':loc,'failure':failure})
    if src_icu:
        icu_rows.append({'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'sourceProfile':src_icu,'currentProfile':top_icu(cur_nodes),'finalProfile':fin_icu,'valid':valid,'failure':failure or None,'requiredPluralCategories':sorted(REQUIRED[loc])})
    source_ph=sorted({k for pr in src_paths for k,v in pr['vars'].items()})
    candidate_terms=sorted(set([term for term in TERMS if hasterm(c['source'],term)]))
    missing=[term for term in candidate_terms if not hasterm(target,term)]
    if missing: protected_missing.append({'position':pos,'sourceId':c['sourceId'],'locale':loc,'missing':missing})
    protected_rows.append({'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'sourceTextSha256':c['sourceTextSha256'],'currentTargetHash':c['currentTargetHash'],'finalTargetHash':sha(target),'sourceProtectedLiterals':candidate_terms,'missingFinal':missing,'valid':not bool(missing)})
    raw_s=tags(c['source']); raw_t=tags(target)
    if raw_s!=raw_t:
        markup_rows.append({'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'sourceTextSha256':c['sourceTextSha256'],'currentTargetHash':c['currentTargetHash'],'finalTargetHash':sha(target),'sourceRawTags':raw_s,'currentRawTags':tags(c['currentTarget']),'finalRawTags':raw_t,'sourceRenderedTagPaths':sorted(src_markup),'finalRenderedTagPaths':sorted(fin_markup),'assessment':'Raw counts differ because the candidate repeats the same balanced rich-text wrapper in locale-specific plural branches; every rendered branch has the same tag sequence as the source.'})
    placeholder_rows.append({'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'sourceTextSha256':c['sourceTextSha256'],'currentTargetHash':c['currentTargetHash'],'finalTargetHash':sha(target),'sourceRenderedVariableProfiles':sorted(src_vars),'finalRenderedVariableProfiles':sorted(fin_vars),'valid':src_vars==fin_vars,'assessment':'Each reachable ICU branch combination retains the same formatter variables exactly once per source render path; variables may move into mutually exclusive plural branches.'})
    if p:
        ctx=contexts[c['sourceId']]
        cand={'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'source':c['source'],'sourceTextSha256':c['sourceTextSha256'],'currentTarget':c['currentTarget'],'currentTargetHash':c['currentTargetHash'],'target':target,'targetHash':sha(target),'kind':p['kind'],'rationale':p.get('rationale'),'confidence':p.get('confidence','moderate'),'callerContextSha256':c['callerContextSha256'],'callerPaths':ctx['callerPaths'],'callerLineHashes':[x['lineSha256'] for x in ctx['pinnedLineRefs']],'primaryProposal':not bool(p.get('crossReviewAdded')),'independentReviewer':p.get('independentReviewer'),'crossReviewDisposition':p.get('crossReviewDisposition'),'crossReviewRationale':p.get('crossReviewRationale'),'branchAwareCorrection':p.get('branchAwareCorrection')}
        candidate_rows.append(cand)
        apply_rows.append({'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'sourceTextSha256':c['sourceTextSha256'],'currentTarget':c['currentTarget'],'currentTargetHash':c['currentTargetHash'],'target':target,'targetHash':sha(target),'kind':p['kind'],'callerContextSha256':c['callerContextSha256'],'callerLineHashes':c['callerPinnedLineHashes'],'confidence':p.get('confidence','moderate'),'rationale':p.get('rationale')})
    if hold: assert p is None,(k,'held source has candidate')
    ledger.append({'schemaVersion':1,'reviewer':'primary + independent machine-assisted semantic review','semanticReviewPerformed':True,'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'source':c['source'],'sourceHash':c['sourceHash'],'sourceTextSha256':c['sourceTextSha256'],'sourceFile':c['sourceFile'],'sourceFileSha256':c['sourceFileSha256'],'sourceCatalogBlob':c['sourceCatalogBlob'],'locale':loc,'localeFile':c['localeFile'],'localeBlob':c['localeBlob'],'localeFileSha256':c['localeFileSha256'],'currentTarget':c['currentTarget'],'currentTargetHash':c['currentTargetHash'],'finalTarget':target,'finalTargetHash':sha(target),'finalDisposition':disposition,'independentVerdict':verdict,'independentRationale':reviews[k].get('rationale'),'primaryReviewDisposition':reconciliation[(pos-3000)*12+LOCS.index(loc)]['primaryReviewDisposition'],'rationale':p.get('rationale') if p else ('Held for source/caller context; do not infer a target.' if hold else 'Both exact-head reviews accepted the current wording in the pinned caller context.'),'confidence':'unknown' if hold else p.get('confidence','moderate') if p else 'moderate','callerContextRef':c['callerContextRef'],'callerContextSha256':c['callerContextSha256'],'callerContextSha256Original':c['callerContextSha256Original'],'callerPaths':c['callerPaths'],'callerLineHashes':c['callerPinnedLineHashes'],'callerUseStatus':c['callerUseStatus'],'callerHold':hold,'sourceRenderedVariableProfiles':sorted(src_vars),'finalRenderedVariableProfiles':sorted(fin_vars),'placeholderParity':'exact-per-rendered-path' if src_vars==fin_vars else 'mismatch','sourceRenderedMarkupPaths':sorted(src_markup),'finalRenderedMarkupPaths':sorted(fin_markup),'markupParity':'exact-per-rendered-path' if src_markup==fin_markup else 'mismatch','sourceIcuProfile':src_icu,'finalIcuProfile':fin_icu,'icuValid':valid,'protectedLiterals':candidate_terms,'finalProtectedLiteralMissing':missing,'nativeSpeakerApproval':'not-performed; qualified native-speaker review remains outstanding'})
    target_rows.append({'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'sourceTextSha256':c['sourceTextSha256'],'currentTarget':c['currentTarget'],'currentTargetHash':c['currentTargetHash'],'finalTarget':target,'finalTargetHash':sha(target),'disposition':disposition,'applyApproved':not bool(hold) and target!=c['currentTarget'],'holdReason':hold.get('holdReason') if hold else None})
assert not structural_errors,structural_errors[:10]
assert not placeholder_path_mismatch,placeholder_path_mismatch[:10]
assert not pound_path_mismatch,pound_path_mismatch[:10]
assert not markup_path_mismatch,markup_path_mismatch[:10]
assert not icu_invalid,icu_invalid[:10]
assert not protected_missing,protected_missing[:10]
assert len(ledger)==len(target_rows)==1200 and len(candidate_rows)==len(apply_rows)==383
assert len(icu_rows)==108 and len(markup_rows)==6 and len(holds)==36
writejl('primary-review-ledger-final.jsonl',ledger)
writejl('candidate-proposals-final.jsonl',candidate_rows)
writejl('exact-apply-list.jsonl',apply_rows)
writejl('protected-literals-review-final.jsonl',protected_rows)
writejl('placeholder-equivalence-review-final.jsonl',placeholder_rows)
writejl('pound-sign-path-review-final.jsonl',pound_rows)
writejl('markup-equivalence-review-final.jsonl',markup_rows)
writej('icu-review-final.json',{'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'profiles':icu_rows,'invalid':icu_invalid,'requiredPluralCategories':{l:sorted(REQUIRED[l]) for l in LOCS},'checkedICUCells':len(icu_rows),'validation':'Every source ICU root/type and exact numeric selector is preserved. Every final plural contains all required locale categories. German W3009 one-selector completion is recorded in the candidate provenance; Arabic exact =0 plus CLDR zero is valid because the exact numeric branch has precedence.'})
writej('placeholder-equivalence-review-final.json',{'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'cellsChecked':1200,'renderedPathMismatchCount':len(placeholder_path_mismatch),'branchAwareScopeChanges':[{'position':3009,'locale':l,'sourceId':cellmap[(3009,l)]['sourceId'],'accounting':'The {type} placeholder is moved into each mutually exclusive rendered plural branch (or kept outside); every rendered path contains the same variables as source.'} for l in ['de','id','ja','ko','zh_Hans','zh_Hant']],'arabicNumberMorphology':'Arabic one/dual forms express the number as طلب واحد / طلبان; # is retained for plural numeric branches. No formatter variable is omitted.','validation':'All 1,200 cells were compared by rendered ICU branch paths; each branch combination preserves the English source placeholder variables.'})
writej('markup-equivalence-review-final.json',{'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'rawMarkupCountMismatchCellsCurrent':sum(1 for c in cells if tags(c['source'])!=tags(c['currentTarget'])),'rawMarkupCountMismatchCellsFinal':len(markup_rows),'renderedTagPathMismatchCount':len(markup_path_mismatch),'semanticallyAccountedFor':len(markup_rows),'unresolvedMarkupGaps':len(markup_path_mismatch),'rows':markup_rows,'validation':'Raw rich-text tag totals differ for pluralized number strings; every rendered branch has the same ordered tag sequence as the English source.'})
writej('pound-sign-path-review-final.json',{'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'cellsChecked':len(pound_rows),'renderedPathMismatchCount':len(pound_path_mismatch),'mismatches':pound_path_mismatch,'validation':'For each reachable ICU branch combination, the count of # number substitutions is preserved. Arabic singular and dual numeric morphology remains explicit; numeric plural branches retain #.'})
writej('protected-literals-review-final.json',{'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'cellsChecked':1200,'protectedLiteralMismatchCellsFinal':len(protected_missing),'mismatches':protected_missing,'validation':'Source-present product names, service names, abbreviations, and identifier literals were checked against each final target.'})
writej('candidate-targets-final.json',{'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'scope':{'sourcePositions':[3000,3099],'sourceIds':100,'locales':LOCS,'cells':1200},'targets':target_rows})
counts=collections.Counter(x['finalDisposition'] for x in ledger); kinds=collections.Counter(x['kind'] for x in candidate_rows); conf=collections.Counter(x['confidence'] for x in ledger)
summary={'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'sourcePositionRange':[3000,3099],'sourceCount':100,'localeCount':12,'cellCount':1200,'finalDispositions':dict(counts),'finalCandidateCount':len(candidate_rows),'finalApplyCount':len(apply_rows),'proposalKinds':dict(kinds),'confidenceCounts':dict(conf),'overallConfidence':'moderate','catalogKeyCounts':{l:readj('head-reattestation.json')['localeCatalogs'][l]['keyCount'] for l in LOCS},'catalogKeySetsIdentical':True,'all12LocaleCellsReviewed':True,'callerContextRows':100,'callerFiles':21,'callerLineReferences':649,'callerAliasRepairs':8,'callerGapsAfterAliasRepair':3,'callerHoldSources':['components.RequestModal.QuotaDisplay.magazinelimit','components.RequestModal.Sportarr.notRequestable','components.RequestModal.autoapproval'],'callerHoldCells':36,'sourceFixRecommendation':'source-fix-recommendation-W3001.json','exactPriorDispositionsReused':0,'previousWindowW2999TargetsMatchingCurrent':12,'forwardBoundaryReadbacksAtW3100':12,'icuCellsChecked':len(icu_rows),'icuInvalidCells':len(icu_invalid),'placeholderRenderedPathMismatches':len(placeholder_path_mismatch),'poundSignRenderedPathMismatches':len(pound_path_mismatch),'markupRenderedPathMismatches':len(markup_path_mismatch),'rawMarkupCountMismatchCellsFinal':len(markup_rows),'protectedLiteralMismatchCellsFinal':len(protected_missing),'independentAdditionalFindings':len(added),'primaryProposalRevisions':len(revised),'independentDispositionCounts':dict(cross_counts),'nativeSpeakerApprovalOutstanding':True,'nativeSpeakerSignoffClaimed':False,'repositoryFilesEdited':False,'testsBuildsScansCiBrowserRun':False,'worktreeStatus':subprocess.check_output(['git','-C',str(REPO),'status','--short'],text=True).splitlines()}
writej('final-summary.json',summary)
writej('finalization-details.json',{'addedFindings':added,'primaryRevisions':revised,'W3009BranchCorrections':[{'locale':'de','before':old_de,'after':new_de,'reason':'German plural requires the locale one category in addition to source exact =0 and other.'},{'locale':'hi','before':old_hi,'after':new_hi,'reason':'Hindi plural requires the locale one category in addition to source exact =0 and other.'}],'inputManualProposalSha256':sha((OUT/'manual-proposals-at-crossreview.jsonl').read_bytes()),'finalMergedManualProposalSha256':sha((OUT/'manual-proposals-merged.jsonl').read_bytes())})
print(json.dumps(summary,ensure_ascii=False,indent=2))
