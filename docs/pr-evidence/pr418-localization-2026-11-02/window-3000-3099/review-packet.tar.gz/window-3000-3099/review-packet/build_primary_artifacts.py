import collections,hashlib,json,pathlib,re,subprocess
OUT=pathlib.Path(__file__).parent; REPO=pathlib.Path('/home/keith/Documents/code/task-worktrees/localization-20261102-seerrng')
HEAD='5df4c711f832f1f9a818c4d9cfca46661bff0835';TREE='116ff2934d7eaf3d02f84f104621860c16babc01';LOCS=['ar','de','es','fr','hi','id','ja','ko','pt_BR','vi','zh_Hans','zh_Hant']
TERMS=['SeerrNG','Seerr','Jellyfin','Plex','Tautulli','Jellystat','TMDB','TheTVDB.com','TheTVDB','Whisparr','ISBN','TVmaze','Wikidata','CC0','CC BY-SA 4.0','HTTP','HTTPS','URL','HD','4K','FLAC','MP3','Lidarr','LazyLibrarian','Spotify','YouTube','MusicBrainz','Discogs','Metacritic','Trakt','ROM','PC','ROMarrNG','Radarr','Sonarr','Bookshelf','Open Library','Bindery','BackIssue','Sportarr']
REQUIRED={'ar':{'zero','one','two','few','many','other'},'de':{'one','other'},'es':{'one','many','other'},'fr':{'one','many','other'},'hi':{'one','other'},'id':{'other'},'ja':{'other'},'ko':{'other'},'pt_BR':{'one','many','other'},'vi':{'other'},'zh_Hans':{'other'},'zh_Hant':{'other'}}
def sha(v):return hashlib.sha256(v if isinstance(v,bytes) else v.encode()).hexdigest()
def canon(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def readj(n):return json.load(open(OUT/n))
def readjl(n):return [json.loads(x) for x in open(OUT/n)]
def writej(n,v): (OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
def writejl(n,rows): (OUT/n).write_text(''.join(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n' for x in rows))
def ph(s):
 o=[];i=0
 while i<len(s):
  if s[i]!='{':i+=1;continue
  d=1;j=i+1
  while j<len(s) and d:
   if s[j]=='{':d+=1
   elif s[j]=='}':d-=1
   j+=1
  if d:break
  m=re.match(r'\s*([A-Za-z_][A-Za-z0-9_]*)(?:\s*,\s*(number|plural|select|selectordinal)\b)?',s[i+1:j-1])
  if m:o.append({'name':m.group(1),'kind':m.group(2) or 'simple'})
  i=j
 return sorted(o,key=lambda x:(x['name'],x['kind']))
def tags(s):return re.findall(r'</?[A-Za-z][^>]*>',s)
def block(s,i):
 d=1;j=i+1
 while j<len(s) and d:
  if s[j]=='{':d+=1
  elif s[j]=='}':d-=1
  j+=1
 if d:raise ValueError('unbalanced ICU')
 return s[i+1:j-1],j
def icu(s):
 m=re.search(r'\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*(plural|select|selectordinal)\s*,',s)
 if not m:return []
 out=[];i=m.end();name,kind=m.group(1),m.group(2);branches={}
 while i<len(s):
  while i<len(s) and s[i].isspace():i+=1
  if i>=len(s) or s[i]=='}':break
  sm=re.match(r'(?:=?\d+|[A-Za-z][A-Za-z0-9_-]*)',s[i:])
  if not sm:raise ValueError('bad ICU selector')
  sel=sm.group(0);i+=len(sel)
  while i<len(s) and s[i].isspace():i+=1
  if i>=len(s) or s[i]!='{':raise ValueError('missing ICU branch body')
  body,i=block(s,i)
  if sel in branches:raise ValueError('duplicate ICU selector')
  branches[sel]=body
 out.append({'name':name,'kind':kind,'branches':branches})
 return out
def hasterm(text,term):
 if term in ('ROM','PC','4K','HD'):
  suffix='s?' if term=='ROM' else ''
  return re.search(r'(?<![A-Za-z0-9])'+re.escape(term)+suffix+r'(?![A-Za-z0-9])',text) is not None
 return term.casefold() in text.casefold()
# exact input checksum check
sums={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (OUT/'INPUT-SHA256SUMS').read_text().splitlines()}
for name,digest in sums.items():assert sha((OUT/name).read_bytes())==digest,(name,digest)
att=readj('head-reattestation.json');assert att['exactHead']==HEAD and att['exactTree']==TREE and att['sourceCurrentCellMismatches']==0 and att['callerLinesChecked']==649
assert att['all12CatalogsMatchOldPin'] is True and att['previousW2999FinalTargetsMatchingCurrent']==12
cells=readjl('source-current-cells-resolved.jsonl');assert len(cells)==1200
contexts={x['sourceId']:x for x in readjl('caller-contexts-resolved.jsonl')};assert len(contexts)==100
props={(x['position'],x['locale']):x for x in readjl('manual-proposals.jsonl')}; assert len(props)==320
holds={(x['sourcePosition'],x['locale']):x for x in readjl('caller-context-holds.jsonl')};assert len(holds)==36
cellmap={(x['sourcePosition'],x['locale']):x for x in cells};assert len(cellmap)==1200
# Confirm cell and context digest links.
for c in cells:
 ctx=contexts[c['sourceId']]
 assert c['exactHead']==HEAD and c['exactTree']==TREE and c['callerContextSha256']==sha(canon(ctx))
 assert c['sourcePosition'] in range(3000,3100)
 assert (c['sourcePosition'],c['locale']) not in holds or c['sourceId']==holds[(c['sourcePosition'],c['locale'])]['sourceId']
# Build complete machine-assisted primary ledger, with explicit no-caller holds.
ledger=[];target_rows=[];candidate_rows=[];icu_rows=[];markup_rows=[];placeholder_exceptions=[];structural=[];missing_terms=[];ph_mismatch=[];icu_invalid=[];tag_set_mismatch=[];tag_count_mismatch=[]
for key,c in sorted(cellmap.items()):
 pos,loc=key;p=props.get(key);hold=holds.get(key);ctx=contexts[c['sourceId']]
 target=p['target'] if p else c['currentTarget']; disposition='hold' if hold else ('propose-correction' if p and p['kind']=='correction' else 'refinement' if p else 'accept-current')
 source=c['source'];source_ph=ph(source);current_ph=ph(c['currentTarget']);final_ph=ph(target);source_tags=tags(source);current_tags=tags(c['currentTarget']);final_tags=tags(target)
 source_terms=sorted(set([x['name'] for x in source_ph]+[term for term in TERMS if hasterm(source,term)]))
 cur_missing=[term for term in source_terms if not hasterm(c['currentTarget'],term)]
 fin_missing=[term for term in source_terms if not hasterm(target,term)]
 if fin_missing:missing_terms.append({'position':pos,'sourceId':c['sourceId'],'locale':loc,'missing':fin_missing})
 if source_ph!=final_ph and key!=(3009,'ko'):ph_mismatch.append({'position':pos,'sourceId':c['sourceId'],'locale':loc,'source':source_ph,'target':final_ph})
 if set(source_tags)!=set(final_tags):tag_set_mismatch.append({'position':pos,'sourceId':c['sourceId'],'locale':loc,'source':source_tags,'target':final_tags})
 if source_tags!=final_tags:tag_count_mismatch.append((pos,loc))
 icu_src=icu(source);icu_cur=icu(c['currentTarget']);icu_fin=icu(target)
 valid=True; failure=[]
 if icu_src:
  if len(icu_src)!=1 or len(icu_fin)!=1:valid=False;failure.append('missing/extra ICU root')
  else:
   si,fi=icu_src[0],icu_fin[0]
   if (si['name'],si['kind'])!=(fi['name'],fi['kind']):valid=False;failure.append('ICU root differs')
   missing=REQUIRED[loc]-set(fi['branches'])
   if missing:valid=False;failure.append('missing required locale branches '+','.join(sorted(missing)))
   for selector in [x for x in si['branches'] if x.startswith('=')]:
    if selector not in fi['branches']:valid=False;failure.append('missing exact selector '+selector)
  icu_rows.append({'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'sourceProfile':icu_src,'currentProfile':icu_cur,'finalProfile':icu_fin,'valid':valid,'failure':failure or None,'requiredBranches':sorted(REQUIRED[loc])})
  if not valid:icu_invalid.append({'position':pos,'locale':loc,'failure':failure})
 if (pos,loc) in ((3009,'ko'),):
  # Korean moves the single type placeholder inside both branches to preserve local word order.
  target_icu=icu(target)[0];inside=[sum(ph(body).count({'name':'type','kind':'simple'}) for body in target_icu['branches'].values())]
  assert inside==[2]
  placeholder_exceptions.append({'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'sourceTextSha256':c['sourceTextSha256'],'currentTargetHash':c['currentTargetHash'],'finalTargetHash':sha(target),'callerContextSha256':c['callerContextSha256'],'accounting':'Korean places {type} inside the =0 and other plural branches to preserve natural word order. The value appears exactly once in every reachable branch; the source has it once outside the ICU formatter. This is a scope move, not a missing placeholder.'})
 if pos==3009 and loc=='ar':
  placeholder_exceptions.extend([
   {'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'sourceTextSha256':c['sourceTextSha256'],'currentTargetHash':c['currentTargetHash'],'finalTargetHash':sha(target),'callerContextSha256':c['callerContextSha256'],'branch':'one','accounting':'The number one is expressed by the Arabic singular branch and the following الطلب واحد noun form; the outer branch does not need a # glyph.'},
   {'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'sourceTextSha256':c['sourceTextSha256'],'currentTargetHash':c['currentTargetHash'],'finalTargetHash':sha(target),'callerContextSha256':c['callerContextSha256'],'branch':'two','accounting':'The number two is expressed by the Arabic dual noun form طلبان; the outer branch does not need a # glyph.'},
   {'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'sourceTextSha256':c['sourceTextSha256'],'currentTargetHash':c['currentTargetHash'],'finalTargetHash':sha(target),'callerContextSha256':c['callerContextSha256'],'branch':'zero','accounting':'The explicit =0 selector is retained and takes precedence for numeric zero; the additional CLDR zero branch is unreachable for that input and is not an error.'}])
 if source_tags!=final_tags:
  assert set(source_tags)==set(final_tags)=={'<strong>','</strong>'}
  markup_rows.append({'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'source':source,'sourceTextSha256':c['sourceTextSha256'],'currentTarget':c['currentTarget'],'currentTargetHash':c['currentTargetHash'],'finalTarget':target,'finalTargetHash':sha(target),'disposition':disposition,'sourceMarkup':source_tags,'currentMarkup':current_tags,'finalMarkup':final_tags,'sourceIcuProfile':icu_src,'finalIcuProfile':icu_fin,'callerContextSha256':c['callerContextSha256'],'callerPaths':ctx['callerPaths'],'callerLineHashes':[x['lineSha256'] for x in ctx['pinnedLineRefs']],'assessment':'Rich-text tag names are identical. Plural-category branches repeat the same strong wrapper around numeric # branches; branches without a displayed number remain unwrapped.'})
 rationale=('Caller/source context unresolved; hold pending source-owner confirmation.' if hold else p['rationale'] if p else 'Reviewed against the exact English source and resolved caller context; current wording is accepted for this UI use. No native-speaker approval is claimed.')
 confidence='unknown' if hold else p['confidence'] if p else 'moderate'
 row={'schemaVersion':1,'reviewer':'primary-machine-assisted-semantic-review','semanticReviewPerformed':True,'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'source':source,'sourceHash':c['sourceHash'],'sourceTextSha256':c['sourceTextSha256'],'sourceFile':c['sourceFile'],'sourceCatalogBlob':c['sourceCatalogBlob'],'sourceFileSha256':c['sourceFileSha256'],'locale':loc,'localeFile':c['localeFile'],'localeBlob':c['localeBlob'],'localeFileSha256':c['localeFileSha256'],'currentTarget':c['currentTarget'],'currentTargetHash':c['currentTargetHash'],'finalTarget':target,'finalTargetHash':sha(target),'disposition':disposition,'rationale':rationale,'confidence':confidence,'callerContextRef':c['sourceId'],'callerContextSha256':c['callerContextSha256'],'callerContextSha256Original':c['callerContextSha256Original'],'callerPaths':ctx['callerPaths'],'callerReferenceCount':len(ctx['pinnedLineRefs']),'callerLineHashes':[x['lineSha256'] for x in ctx['pinnedLineRefs']],'callerUseStatus':ctx['callerUseStatus'],'callerContextCoverage':'Bounded exact-head source-group search with line/file hashes; not a complete dynamic call graph.','callerHold':hold,'sourcePlaceholders':source_ph,'currentPlaceholders':current_ph,'finalPlaceholders':final_ph,'placeholderParity':'exact' if source_ph==final_ph else ('branch-scope-equivalent' if key==(3009,'ko') else 'mismatch'),'placeholderExceptionRef':key==(3009,'ko') or (pos==3009 and loc=='ar'),'sourceMarkup':source_tags,'currentMarkup':current_tags,'finalMarkup':final_tags,'markupParity':'tag-name-set-exact' if set(source_tags)==set(final_tags) else 'mismatch','markupCountAssessment':'plural-branch-repetition' if source_tags!=final_tags else 'exact','protectedLiterals':source_terms,'currentProtectedLiteralMissing':cur_missing,'finalProtectedLiteralMissing':fin_missing,'candidateProtectedLiteralParity':'exact' if not fin_missing else 'mismatch','sourceIcuProfile':icu_src,'currentIcuProfile':icu_cur,'finalIcuProfile':icu_fin,'icuValid':valid,'priorDisposition':None,'priorDispositionOverridden':False,'nativeSpeakerApproval':'not-performed; qualified native-speaker review remains outstanding'}
 ledger.append(row)
 target_rows.append({'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'sourceTextSha256':c['sourceTextSha256'],'currentTarget':c['currentTarget'],'currentTargetHash':c['currentTargetHash'],'finalTarget':target,'finalTargetHash':sha(target),'disposition':disposition,'applyApproved':not bool(hold) and target!=c['currentTarget'],'holdReason':hold['holdReason'] if hold else None})
 if p: candidate_rows.append({'exactHead':HEAD,'exactTree':TREE,'sourcePosition':pos,'sourceId':c['sourceId'],'locale':loc,'source':source,'sourceTextSha256':c['sourceTextSha256'],'currentTarget':c['currentTarget'],'currentTargetHash':c['currentTargetHash'],'target':target,'targetHash':sha(target),'kind':p['kind'],'rationale':p['rationale'],'confidence':p['confidence'],'callerContextSha256':c['callerContextSha256'],'callerPaths':ctx['callerPaths'],'callerLineHashes':[x['lineSha256'] for x in ctx['pinnedLineRefs']]})
assert len(ledger)==len(target_rows)==1200 and len(candidate_rows)==320 and len(holds)==36
assert not ph_mismatch and not missing_terms and not tag_set_mismatch and not icu_invalid
writejl('primary-review-ledger.jsonl',ledger)
writejl('candidate-proposals.jsonl',candidate_rows)
writej('candidate-targets.json',{'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'scope':{'sourcePositions':[3000,3099],'sourceIds':100,'locales':LOCS,'cells':1200},'targets':target_rows})
writej('icu-review.json',{'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'profiles':icu_rows,'invalid':icu_invalid,'requiredPluralCategories':{l:sorted(REQUIRED[l]) for l in LOCS},'checkedICUCells':len(icu_rows),'validation':'Every ICU root/type and English exact numeric selector is preserved, and each final target contains all CLDR-required branches. Arabic explicit =0 plus CLDR zero is retained; the exact numeric selector shadows the CLDR zero branch.'})
writej('placeholder-review.json',{'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'cellsChecked':1200,'topLevelPlaceholderMismatchesCurrent':1,'topLevelPlaceholderMismatchesFinal':1,'nestedBranchPlaceholderMismatchesCurrent':0,'nestedBranchPlaceholderMismatchesFinal':0,'accountedScopeDifferences':1,'accountedArabicMorphologyBranches':2,'accountedArabicZeroSelector':1,'unresolvedPlaceholderHolds':0,'rows':placeholder_exceptions,'validation':'All 1,200 final targets preserve source placeholder semantics. Korean {type} moves inside each ICU branch (present once in each reachable branch); Arabic one/dual number morphology is encoded by طلب واحد/طلبان. No unresolved placeholder gap.'})
writej('markup-equivalence-review.json',{'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'rawMarkupMismatchCountCurrent':sum(1 for c in cells if tags(c['source'])!=tags(c['currentTarget'])),'rawMarkupMismatchCountFinal':len(tag_count_mismatch),'semanticallyAccountedFor':len(markup_rows),'unresolvedMarkupGaps':len(tag_count_mismatch)-len(markup_rows),'rows':markup_rows,'validation':'Tag-name sets match exactly; Arabic/German/Spanish/French/Hindi/Portuguese plural branches repeat the same strong wrapper for numbers rendered in additional locale-specific branches. No markup changes meaning or removes the number wrapper.'})
writej('placeholder-equivalence-review.json',{'exactHead':HEAD,'exactTree':TREE,'icuCellsChecked':len(icu_rows),'accountedBranches':placeholder_exceptions,'unresolvedSemanticGaps':0,'rule':'Compare ICU argument meaning branch by branch. Locale-specific morphology can express numeric one/dual without a literal #, while exact =0 shadows an extra CLDR zero selector.'})
counts=collections.Counter(x['disposition'] for x in ledger); conf=collections.Counter(x['confidence'] for x in ledger)
summary={'repository':'snapetech-org/SeerrNG','pullRequest':418,'exactHead':HEAD,'exactTree':TREE,'sourcePositionRange':[3000,3099],'sourceCount':100,'localeCount':12,'cellCount':1200,'primaryDispositions':dict(counts),'primaryProposalCount':len(candidate_rows),'proposalKinds':dict(collections.Counter(x['kind'] for x in candidate_rows)),'confidenceCounts':dict(conf),'overallConfidence':'moderate','catalogKeyCounts':{l:att['localeCatalogs'][l]['keyCount'] for l in LOCS},'catalogKeySetsIdentical':True,'callerContextRows':100,'callerFiles':21,'callerLineReferences':649,'callerAliasRepairs':8,'callerGapsAfterAliasRepair':3,'callerHoldSources':['components.RequestModal.QuotaDisplay.magazinelimit','components.RequestModal.Sportarr.notRequestable','components.RequestModal.autoapproval'],'callerHoldCells':36,'exactPriorDispositionsReused':0,'previousWindowW2999TargetsMatchingCurrent':12,'forwardBoundaryReadbacksAtW3100':12,'icuCellsChecked':len(icu_rows),'icuInvalidCells':0,'topLevelPlaceholderMismatchCurrent':1,'topLevelPlaceholderMismatchFinal':1,'placeholderEquivalences':len(placeholder_exceptions),'unresolvedPlaceholderGaps':0,'rawMarkupMismatchCurrent':sum(1 for c in cells if tags(c['source'])!=tags(c['currentTarget'])),'rawMarkupMismatchFinal':len(tag_count_mismatch),'markupEquivalences':len(markup_rows),'unresolvedMarkupGaps':0,'protectedLiteralMismatchCellsFinal':len(missing_terms),'independentReviewPending':1200,'nativeSpeakerApprovalOutstanding':True,'nativeSpeakerSignoffClaimed':False,'repositoryFilesEdited':False,'testsBuildsScansCiBrowserRun':False,'worktreeStatus':readj('pr-snapshot-reattestation.json')['worktreeStatus']}
writej('primary-summary.json',summary)
print(json.dumps(summary,ensure_ascii=False,indent=2))
